package main

import (
	"archive/zip"
	"bytes"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"golang.org/x/crypto/ssh"
)

type Server struct {
	ID               string `json:"id"`
	Name             string `json:"name"`
	Host             string `json:"host"`
	SSHPort          int    `json:"ssh_port"`
	SSHUser          string `json:"ssh_user"`
	SSHPassword      string `json:"ssh_password,omitempty"`
	SSHKey           string `json:"ssh_key,omitempty"`
	SSHKeyPassphrase string `json:"ssh_key_passphrase,omitempty"`
	UseKey           bool   `json:"use_key"`
	DNS1             string `json:"dns1"`
	DNS2             string `json:"dns2"`
	ManualPorts      bool   `json:"manual_ports"`
	DTLS             int    `json:"dtls_port"`
	WG               int    `json:"wg_port"`
	AdminPort        int    `json:"admin_port"`
	Direct           int    `json:"direct_port"`
	Raw              int    `json:"raw_port"`
	AdminToken       string `json:"admin_token,omitempty"`
	AdminPin         string `json:"admin_pin,omitempty"`
	MainPassword     string `json:"main_password,omitempty"`
	BotToken         string `json:"bot_token,omitempty"`
	Installed        bool   `json:"installed"`
	LastDeploy       string `json:"last_deploy,omitempty"`
}

type ServerPublic struct {
	ID              string `json:"id"`
	Name            string `json:"name"`
	Host            string `json:"host"`
	SSHPort         int    `json:"ssh_port"`
	SSHUser         string `json:"ssh_user"`
	UseKey          bool   `json:"use_key"`
	DNS1            string `json:"dns1"`
	DNS2            string `json:"dns2"`
	ManualPorts     bool   `json:"manual_ports"`
	DTLS            int    `json:"dtls_port"`
	WG              int    `json:"wg_port"`
	AdminPort       int    `json:"admin_port"`
	Direct          int    `json:"direct_port"`
	Raw             int    `json:"raw_port"`
	Installed       bool   `json:"installed"`
	LastDeploy      string `json:"last_deploy,omitempty"`
	HasSSHKey       bool   `json:"has_ssh_key"`
	HasSSHPass      bool   `json:"has_ssh_password"`
	HasMainPassword bool   `json:"has_main_password"`
	HasBotToken     bool   `json:"has_bot_token"`
	HasAdminToken   bool   `json:"has_admin_token"`
	AdminPin        string `json:"admin_pin,omitempty"`
}

func publicServer(s Server) ServerPublic {
	return ServerPublic{ID: s.ID, Name: s.Name, Host: s.Host, SSHPort: s.SSHPort, SSHUser: s.SSHUser, UseKey: s.UseKey, DNS1: s.DNS1, DNS2: s.DNS2, ManualPorts: s.ManualPorts, DTLS: s.DTLS, WG: s.WG, AdminPort: s.AdminPort, Direct: s.Direct, Raw: s.Raw, Installed: s.Installed, LastDeploy: s.LastDeploy, HasSSHKey: s.SSHKey != "", HasSSHPass: s.SSHPassword != "", HasMainPassword: s.MainPassword != "", HasBotToken: s.BotToken != "", HasAdminToken: s.AdminToken != "", AdminPin: s.AdminPin}
}

type Profile struct {
	ID                   string `json:"id"`
	Name                 string `json:"name"`
	ServerID             string `json:"server_id"`
	Mode                 string `json:"mode,omitempty"` // UI preference; runtime mode may also be global.
	Workers              int    `json:"workers"`
	VKHashes             string `json:"vk_hashes"`
	VKAccount            bool   `json:"vk_account"`
	VKAccessToken        string `json:"vk_access_token,omitempty"`
	VKAccount1Name       string `json:"vk_account1_name,omitempty"`
	VKAccount1Token      string `json:"vk_account1_token,omitempty"`
	VKAccount2Name       string `json:"vk_account2_name,omitempty"`
	VKAccount2Token      string `json:"vk_account2_token,omitempty"`
	VKPrimaryID          string `json:"vk_primary_id,omitempty"`
	VKBackupID           string `json:"vk_backup_id,omitempty"`
	ListenPort           int    `json:"listen_port"`
	Password             string `json:"password,omitempty"`
	UseGlobalHashes      bool   `json:"use_global_hashes"`
	HydraFailoverEnabled bool   `json:"hydra_failover_enabled"`
	HydraProxyName       string `json:"hydra_proxy_name,omitempty"`
	HydraPolicy          string `json:"hydra_policy,omitempty"`
	FolderID             string `json:"folder_id,omitempty"`
}

type TelegramRecipient struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	BotToken string `json:"bot_token,omitempty"`
	ChatID   string `json:"chat_id"`
	Enabled  bool   `json:"enabled"`
}

type TelegramRecipientPublic struct {
	ID         string `json:"id"`
	Name       string `json:"name"`
	ChatID     string `json:"chat_id"`
	Enabled    bool   `json:"enabled"`
	Configured bool   `json:"configured"`
}

type Folder struct {
	ID   string `json:"id"`
	Name string `json:"name"`
}
type Bypass struct {
	Rules []string `json:"rules"`
}

type Store struct {
	Servers  []Server            `json:"servers"`
	Profiles []Profile           `json:"profiles"`
	Folders  []Folder            `json:"folders"`
	Bypass   Bypass              `json:"bypass"`
	Telegram []TelegramRecipient `json:"telegram"`
}

type VKOAuthPending struct {
	ProfileID string
	AccountID string
	ExpiresAt time.Time
}

type App struct {
	mu      sync.Mutex
	root    string
	cfgPath string
	store   Store
	deploy  map[string]*DeployJob
	tunnel  *TunnelProcess
	vkOAuth map[string]VKOAuthPending
}

type DeployJob struct {
	ID       string `json:"id"`
	ServerID string `json:"server_id"`
	State    string `json:"state"`
	Progress int    `json:"progress"`
	Step     string `json:"step"`
	Output   string `json:"output"`
	Error    string `json:"error,omitempty"`
}

func newID() string {
	b := make([]byte, 9)
	_, _ = rand.Read(b)
	return base64.RawURLEncoding.EncodeToString(b)
}
func (a *App) load() error {
	b, err := os.ReadFile(a.cfgPath)
	if os.IsNotExist(err) {
		return a.save()
	}
	if err != nil {
		return err
	}
	return json.Unmarshal(b, &a.store)
}
func (a *App) save() error {
	if err := os.MkdirAll(filepath.Dir(a.cfgPath), 0700); err != nil {
		return err
	}
	b, _ := json.MarshalIndent(a.store, "", "  ")
	// Keep one last-known-good copy so an unexpected power loss cannot destroy
	// the control-plane configuration. The live file is still replaced
	// atomically via rename().
	if old, err := os.ReadFile(a.cfgPath); err == nil {
		_ = os.WriteFile(a.cfgPath+".bak", old, 0600)
	}
	tmp := a.cfgPath + ".tmp"
	if err := os.WriteFile(tmp, b, 0600); err != nil {
		return err
	}
	return os.Rename(tmp, a.cfgPath)
}
func jsonOut(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	_ = json.NewEncoder(w).Encode(v)
}
func body(w http.ResponseWriter, r *http.Request, v any) error {
	if r.Body == nil {
		return errors.New("empty body")
	}
	return json.NewDecoder(r.Body).Decode(v)
}
func (a *App) servers(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	defer a.mu.Unlock()
	out := make([]ServerPublic, 0, len(a.store.Servers))
	for _, s := range a.store.Servers {
		out = append(out, publicServer(s))
	}
	jsonOut(w, out)
}

func (a *App) serverSave(w http.ResponseWriter, r *http.Request) {
	var s Server
	if err := body(w, r, &s); err != nil {
		http.Error(w, "bad json", 400)
		return
	}
	if s.ID == "" {
		s.ID = newID()
	}
	if s.Name == "" {
		s.Name = s.Host
	}
	if s.SSHPort == 0 {
		s.SSHPort = 22
	}
	if s.SSHUser == "" {
		s.SSHUser = "root"
	}
	if s.DTLS == 0 {
		s.DTLS = 56100
	}
	if s.WG == 0 {
		s.WG = 56101
	}
	if s.AdminPort == 0 {
		s.AdminPort = 56102
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	found := false
	for i := range a.store.Servers {
		if a.store.Servers[i].ID == s.ID {
			old := a.store.Servers[i]
			// UI sends redacted server records; never erase stored secrets unless a new value is supplied.
			if s.SSHPassword == "" {
				s.SSHPassword = old.SSHPassword
			}
			if s.SSHKey == "" {
				s.SSHKey = old.SSHKey
			}
			if s.SSHKeyPassphrase == "" {
				s.SSHKeyPassphrase = old.SSHKeyPassphrase
			}
			if s.AdminToken == "" {
				s.AdminToken = old.AdminToken
			}
			if s.AdminPin == "" {
				s.AdminPin = old.AdminPin
			}
			if s.MainPassword == "" {
				s.MainPassword = old.MainPassword
			}
			if s.BotToken == "" {
				s.BotToken = old.BotToken
			}
			if s.DTLS == 0 {
				s.DTLS = old.DTLS
			}
			if s.WG == 0 {
				s.WG = old.WG
			}
			if s.AdminPort == 0 {
				s.AdminPort = old.AdminPort
			}
			a.store.Servers[i] = s
			found = true
			break
		}
	}
	if !found {
		a.store.Servers = append(a.store.Servers, s)
	}
	if err := a.save(); err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	jsonOut(w, s)
}

func (a *App) serverDelete(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		http.Error(w, "id required", 400)
		return
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	for i := range a.store.Servers {
		if a.store.Servers[i].ID == id {
			a.store.Servers = append(a.store.Servers[:i], a.store.Servers[i+1:]...)
			if err := a.save(); err != nil {
				http.Error(w, err.Error(), 500)
				return
			}
			jsonOut(w, map[string]any{"ok": true})
			return
		}
	}
	http.Error(w, "server not found", 404)
}

type ProfilePublic struct {
	ID                   string `json:"id"`
	Name                 string `json:"name"`
	ServerID             string `json:"server_id"`
	Mode                 string `json:"mode,omitempty"`
	Workers              int    `json:"workers"`
	VKHashes             string `json:"vk_hashes"`
	VKAccount            bool   `json:"vk_account"`
	VKAccessTokenSet     bool   `json:"vk_access_token_set"`
	VKAccount1Set        bool   `json:"vk_account1_set"`
	VKAccount2Set        bool   `json:"vk_account2_set"`
	VKAccount1Name       string `json:"vk_account1_name,omitempty"`
	VKAccount2Name       string `json:"vk_account2_name,omitempty"`
	VKPrimaryID          string `json:"vk_primary_id,omitempty"`
	VKBackupID           string `json:"vk_backup_id,omitempty"`
	ListenPort           int    `json:"listen_port"`
	UseGlobalHashes      bool   `json:"use_global_hashes"`
	HydraFailoverEnabled bool   `json:"hydra_failover_enabled"`
	HydraProxyName       string `json:"hydra_proxy_name,omitempty"`
	HydraPolicy          string `json:"hydra_policy,omitempty"`
	FolderID             string `json:"folder_id,omitempty"`
	PasswordSet          bool   `json:"password_set"`
}

func publicProfile(p Profile) ProfilePublic {
	return ProfilePublic{ID: p.ID, Name: p.Name, ServerID: p.ServerID, Mode: p.Mode, Workers: p.Workers, VKHashes: p.VKHashes, VKAccount: p.VKAccount, VKAccessTokenSet: p.VKAccessToken != "", VKAccount1Set: p.VKAccount1Token != "", VKAccount2Set: p.VKAccount2Token != "", VKAccount1Name: p.VKAccount1Name, VKAccount2Name: p.VKAccount2Name, VKPrimaryID: p.VKPrimaryID, VKBackupID: p.VKBackupID, ListenPort: p.ListenPort, UseGlobalHashes: p.UseGlobalHashes, HydraFailoverEnabled: p.HydraFailoverEnabled, HydraProxyName: p.HydraProxyName, HydraPolicy: p.HydraPolicy, FolderID: p.FolderID, PasswordSet: p.Password != ""}
}
func (a *App) profiles(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	defer a.mu.Unlock()
	out := make([]ProfilePublic, 0, len(a.store.Profiles))
	for _, p := range a.store.Profiles {
		out = append(out, publicProfile(p))
	}
	jsonOut(w, out)
}
func (a *App) profileDelete(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		http.Error(w, "id required", 400)
		return
	}
	a.mu.Lock()
	var target *Profile
	for i := range a.store.Profiles {
		if a.store.Profiles[i].ID == id {
			cp := a.store.Profiles[i]
			target = &cp
			break
		}
	}
	a.mu.Unlock()
	if target == nil {
		http.Error(w, "profile not found", 404)
		return
	}
	// A deleted profile must never leave its latched HydraRoute policy behind.
	// A merely configured-but-disabled profile must not mutate the user's policy.
	needDisable := target.HydraFailoverEnabled
	if !needDisable && target.HydraProxyName != "" {
		if out, err := qwdttHydraCommand("status", target.HydraProxyName, target.HydraPolicy); err == nil && strings.Contains(out, "FAILOVER_ACTIVE=1") {
			needDisable = true
		}
	}
	if needDisable {
		if _, err := qwdttHydraCommand("disable", target.HydraProxyName, target.HydraPolicy); err != nil {
			http.Error(w, "cannot disable HydraRoute failover: "+err.Error(), 500)
			return
		}
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	for i, p := range a.store.Profiles {
		if p.ID == id {
			a.store.Profiles = append(a.store.Profiles[:i], a.store.Profiles[i+1:]...)
			if err := a.save(); err != nil {
				http.Error(w, err.Error(), 500)
				return
			}
			jsonOut(w, map[string]any{"ok": true})
			return
		}
	}
	http.Error(w, "profile not found", 404)
}
func (a *App) folders(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if r.Method == "GET" {
		jsonOut(w, a.store.Folders)
		return
	}
	var f Folder
	if err := body(w, r, &f); err != nil {
		http.Error(w, "bad json", 400)
		return
	}
	if f.ID == "" {
		f.ID = newID()
	}
	if strings.TrimSpace(f.Name) == "" {
		http.Error(w, "name required", 400)
		return
	}
	found := false
	for i := range a.store.Folders {
		if a.store.Folders[i].ID == f.ID {
			a.store.Folders[i] = f
			found = true
			break
		}
	}
	if !found {
		a.store.Folders = append(a.store.Folders, f)
	}
	_ = a.save()
	jsonOut(w, f)
}
func (a *App) folderDelete(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		http.Error(w, "id required", 400)
		return
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	for i, f := range a.store.Folders {
		if f.ID == id {
			a.store.Folders = append(a.store.Folders[:i], a.store.Folders[i+1:]...)
			for j := range a.store.Profiles {
				if a.store.Profiles[j].FolderID == id {
					a.store.Profiles[j].FolderID = ""
				}
			}
			_ = a.save()
			jsonOut(w, map[string]any{"ok": true})
			return
		}
	}
	http.Error(w, "folder not found", 404)
}
func (a *App) profileExport(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	ps := append([]Profile(nil), a.store.Profiles...)
	a.mu.Unlock()
	var buf bytes.Buffer
	zw := zip.NewWriter(&buf)
	writer, err := zw.Create("profiles.json")
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	type QProfile struct {
		Name                 string `json:"name"`
		Peer                 string `json:"peer"`
		Hashes               string `json:"hashes"`
		Workers              int    `json:"workers"`
		Port                 int    `json:"port"`
		Password             string `json:"password"`
		HydraFailoverEnabled bool   `json:"hydra_failover_enabled"`
		HydraProxyName       string `json:"hydra_proxy_name"`
		HydraPolicy          string `json:"hydra_policy"`
	}
	out := make([]QProfile, 0, len(ps))
	for _, p := range ps {
		peer := ""
		a.mu.Lock()
		for _, s := range a.store.Servers {
			if s.ID == p.ServerID {
				peer = net.JoinHostPort(s.Host, strconv.Itoa(s.DTLS))
				break
			}
		}
		a.mu.Unlock()
		out = append(out, QProfile{Name: p.Name, Peer: peer, Hashes: p.VKHashes, Workers: p.Workers, Port: p.ListenPort, Password: p.Password, HydraFailoverEnabled: p.HydraFailoverEnabled, HydraProxyName: p.HydraProxyName, HydraPolicy: p.HydraPolicy})
	}
	b, _ := json.MarshalIndent(map[string]any{"version": 1, "profiles": out}, "", "  ")
	_, _ = writer.Write(b)
	_ = zw.Close()
	w.Header().Set("Content-Type", "application/zip")
	w.Header().Set("Content-Disposition", `attachment; filename="qwdtt-profiles.zip"`)
	_, _ = w.Write(buf.Bytes())
}
func (a *App) profileImport(w http.ResponseWriter, r *http.Request) {
	if err := r.ParseMultipartForm(8 << 20); err != nil {
		http.Error(w, err.Error(), 400)
		return
	}
	f, _, err := r.FormFile("file")
	if err != nil {
		http.Error(w, "file required", 400)
		return
	}
	defer f.Close()
	data, err := io.ReadAll(io.LimitReader(f, 8<<20))
	if err != nil {
		http.Error(w, err.Error(), 400)
		return
	}
	zr, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		http.Error(w, "invalid ZIP", 400)
		return
	}
	var raw []byte
	for _, z := range zr.File {
		if z.Name == "profiles.json" {
			rc, e := z.Open()
			if e != nil {
				http.Error(w, e.Error(), 400)
				return
			}
			raw, _ = io.ReadAll(io.LimitReader(rc, 8<<20))
			rc.Close()
			break
		}
	}
	if len(raw) == 0 {
		http.Error(w, "profiles.json not found", 400)
		return
	}
	var pack struct {
		Profiles []struct {
			Name                 string `json:"name"`
			Peer                 string `json:"peer"`
			Hashes               string `json:"hashes"`
			Workers              int    `json:"workers"`
			Port                 int    `json:"port"`
			Password             string `json:"password"`
			HydraFailoverEnabled bool   `json:"hydra_failover_enabled"`
			HydraProxyName       string `json:"hydra_proxy_name"`
			HydraPolicy          string `json:"hydra_policy"`
		} `json:"profiles"`
	}
	if err = json.Unmarshal(raw, &pack); err != nil {
		http.Error(w, err.Error(), 400)
		return
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	imported := 0
	for _, q := range pack.Profiles {
		if strings.TrimSpace(q.Name) == "" || strings.TrimSpace(q.Peer) == "" {
			continue
		}
		host, port, err := net.SplitHostPort(q.Peer)
		if err != nil {
			continue
		}
		dtls, _ := strconv.Atoi(port)
		var sid string
		for _, sv := range a.store.Servers {
			if sv.Host == host && sv.DTLS == dtls {
				sid = sv.ID
				break
			}
		}
		if sid == "" {
			sid = newID()
			a.store.Servers = append(a.store.Servers, Server{ID: sid, Name: host, Host: host, SSHPort: 22, SSHUser: "root", DTLS: dtls, WG: 56101, AdminPort: 56102})
		}
		p := Profile{ID: newID(), Name: q.Name, ServerID: sid, Workers: q.Workers, VKHashes: q.Hashes, ListenPort: q.Port, Password: q.Password, Mode: "socks5", HydraFailoverEnabled: q.HydraFailoverEnabled, HydraProxyName: q.HydraProxyName, HydraPolicy: q.HydraPolicy}
		if p.Workers < 1 {
			p.Workers = 1
		}
		if p.Workers > 4 {
			p.Workers = 4
		}
		if p.ListenPort < 1 {
			p.ListenPort = 1301
		}
		a.store.Profiles = append(a.store.Profiles, p)
		imported++
	}
	if err := a.save(); err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	jsonOut(w, map[string]any{"ok": true, "imported": imported})
}

func (a *App) vkOAuthStart(w http.ResponseWriter, r *http.Request) {
	profileID := strings.TrimSpace(r.URL.Query().Get("profile_id"))
	if profileID == "" {
		http.Error(w, "profile_id required", 400)
		return
	}
	clientID := strings.TrimSpace(os.Getenv("QWDTT_VK_CLIENT_ID"))
	if clientID == "" {
		http.Error(w, "VK OAuth is not configured: set QWDTT_VK_CLIENT_ID", 503)
		return
	}
	redirectURI := strings.TrimSpace(os.Getenv("QWDTT_VK_REDIRECT_URI"))
	if redirectURI == "" {
		// The URI must exactly match the trusted redirect URI configured in the VK app.
		scheme := "http"
		if r.TLS != nil {
			scheme = "https"
		}
		redirectURI = scheme + "://" + r.Host + "/vk/callback"
	}
	a.mu.Lock()
	found := false
	for _, p := range a.store.Profiles {
		if p.ID == profileID {
			found = true
			break
		}
	}
	if !found {
		a.mu.Unlock()
		http.Error(w, "profile not found", 404)
		return
	}
	stateBytes := make([]byte, 24)
	if _, err := rand.Read(stateBytes); err != nil {
		a.mu.Unlock()
		http.Error(w, err.Error(), 500)
		return
	}
	state := base64.RawURLEncoding.EncodeToString(stateBytes)
	if a.vkOAuth == nil {
		a.vkOAuth = map[string]VKOAuthPending{}
	}
	accountID := strings.TrimSpace(r.URL.Query().Get("account_id"))
	if accountID != "1" && accountID != "2" {
		accountID = "1"
	}
	a.vkOAuth[state] = VKOAuthPending{ProfileID: profileID, AccountID: accountID, ExpiresAt: time.Now().Add(10 * time.Minute)}
	a.mu.Unlock()
	v := url.Values{}
	v.Set("client_id", clientID)
	v.Set("display", "page")
	v.Set("redirect_uri", redirectURI)
	v.Set("response_type", "token")
	v.Set("scope", "messages")
	v.Set("state", state)
	v.Set("v", "5.199")
	http.Redirect(w, r, "https://oauth.vk.com/authorize?"+v.Encode(), http.StatusFound)
}

func (a *App) vkOAuthCallback(w http.ResponseWriter, r *http.Request) {
	// VK's legacy OAuth token flow returns the access_token in the URL fragment.
	// Fragments are intentionally not sent to the HTTP server, so this tiny local
	// page reads the fragment in the browser and posts only the token + state to
	// the qWDTT API. The token never appears in the server request URL/logs.
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	io.WriteString(w, `<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>qWDTT VK</title><style>body{font:16px sans-serif;background:#0b0d10;color:#eee;padding:24px}button{padding:12px 18px;border-radius:10px;border:0}</style><h3 id="t">Завершаем вход VK…</h3><p id="m"></p><script>(async()=>{const q=new URLSearchParams(location.search);if(q.get('error')){document.getElementById('t').textContent='Вход отменён';document.getElementById('m').textContent=q.get('error_description')||q.get('error');return}const p=new URLSearchParams(location.hash.slice(1));const token=p.get('access_token');const state=p.get('state');if(!token||!state){document.getElementById('t').textContent='VK не вернул токен';document.getElementById('m').textContent='Проверьте Client ID и Trusted Redirect URI в VK и повторите вход.';return}try{const r=await fetch('/api/vk/oauth/complete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({state,access_token:token})});const x=await r.json().catch(()=>({}));if(!r.ok)throw new Error(x.error||'Ошибка');document.getElementById('t').textContent='VK подключён ✓';document.getElementById('m').textContent='Окно можно закрыть.';try{window.opener&&window.opener.postMessage({type:'qwdtt-vk-ok'},location.origin)}catch(e){}setTimeout(()=>window.close(),1200)}catch(e){document.getElementById('t').textContent='Ошибка';document.getElementById('m').textContent=e.message}})()</script>`)
}

func (a *App) vkOAuthComplete(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", 405)
		return
	}
	var req struct {
		State       string `json:"state"`
		AccessToken string `json:"access_token"`
	}
	if err := body(w, r, &req); err != nil || strings.TrimSpace(req.State) == "" || strings.TrimSpace(req.AccessToken) == "" {
		http.Error(w, "bad request", 400)
		return
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	pending, ok := a.vkOAuth[req.State]
	delete(a.vkOAuth, req.State)
	if !ok || time.Now().After(pending.ExpiresAt) {
		http.Error(w, "authorization expired", 400)
		return
	}
	for i := range a.store.Profiles {
		if a.store.Profiles[i].ID == pending.ProfileID {
			token := strings.TrimSpace(req.AccessToken)
			if pending.AccountID == "2" {
				a.store.Profiles[i].VKAccount2Token = token
				if a.store.Profiles[i].VKAccount2Name == "" {
					a.store.Profiles[i].VKAccount2Name = "VK-2"
				}
			} else {
				a.store.Profiles[i].VKAccount1Token = token
				if a.store.Profiles[i].VKAccount1Name == "" {
					a.store.Profiles[i].VKAccount1Name = "VK-1"
				}
			}
			a.store.Profiles[i].VKAccessToken = token
			a.store.Profiles[i].VKAccount = true
			if err := a.save(); err != nil {
				http.Error(w, err.Error(), 500)
				return
			}
			jsonOut(w, map[string]any{"ok": true, "profile_id": pending.ProfileID})
			return
		}
	}
	http.Error(w, "profile not found", 404)
}

func syncKeeneticSOCKS5(port int) {
	if port <= 0 || port > 65535 {
		port = 1301
	}
	if _, err := os.Stat("/opt/etc/init.d/S97qwdtt-proxy"); err != nil {
		return
	}
	cmd := exec.Command("/opt/etc/init.d/S97qwdtt-proxy", "sync", "192.168.1.1", strconv.Itoa(port))
	_ = cmd.Run()
}

func qwdttHydraCommand(action string, proxy, policy string) (string, error) {
	if action != "arm" && action != "failover" && action != "disable" && action != "status" {
		return "", errors.New("invalid hydra failover action")
	}
	if _, err := os.Stat("/opt/etc/init.d/S97qwdtt-failover"); err != nil {
		return "", err
	}
	cmd := exec.Command("/opt/etc/init.d/S97qwdtt-failover", action)
	env := os.Environ()
	if proxy != "" {
		env = append(env, "HYDRA_PROXY_NAME="+proxy)
	}
	if policy != "" {
		env = append(env, "HYDRA_POLICY="+policy)
	}
	cmd.Env = env
	out, err := cmd.CombinedOutput()
	return strings.TrimSpace(string(out)), err
}

func (a *App) hydraFailover(w http.ResponseWriter, r *http.Request) {
	profileID := r.URL.Query().Get("profile_id")
	if profileID == "" {
		http.Error(w, "profile_id required", 400)
		return
	}
	a.mu.Lock()
	var p *Profile
	for i := range a.store.Profiles {
		if a.store.Profiles[i].ID == profileID {
			cp := a.store.Profiles[i]
			p = &cp
			break
		}
	}
	a.mu.Unlock()
	if p == nil {
		http.Error(w, "profile not found", 404)
		return
	}
	if r.Method == "GET" {
		out, err := qwdttHydraCommand("status", p.HydraProxyName, p.HydraPolicy)
		if err != nil {
			jsonOut(w, map[string]any{"ok": false, "enabled": p.HydraFailoverEnabled, "active": false, "armed": p.HydraFailoverEnabled, "error": err.Error()})
			return
		}
		vals := map[string]string{}
		for _, line := range strings.Split(out, "\n") {
			kv := strings.SplitN(strings.TrimSpace(line), "=", 2)
			if len(kv) == 2 {
				vals[kv[0]] = kv[1]
			}
		}
		jsonOut(w, map[string]any{
			"ok": true, "enabled": p.HydraFailoverEnabled,
			"active":          vals["FAILOVER_ACTIVE"] == "1",
			"armed":           vals["AUTO_ARMED"] == "1" || p.HydraFailoverEnabled,
			"manual_disabled": vals["MANUAL_DISABLED"] == "1",
			"activated_at":    vals["ACTIVATED_AT"],
			"hydra_proxy":     vals["HYDRA_PROXY_NAME"],
			"policy":          vals["HYDRA_POLICY"],
		})
		return
	}
	if r.Method != "POST" {
		http.Error(w, "method not allowed", 405)
		return
	}
	var req struct {
		Action string `json:"action"`
	}
	if err := body(w, r, &req); err != nil {
		http.Error(w, "bad json", 400)
		return
	}
	switch req.Action {
	case "enable":
		if _, err := qwdttHydraCommand("arm", p.HydraProxyName, p.HydraPolicy); err != nil {
			http.Error(w, err.Error(), 500)
			return
		}
		p.HydraFailoverEnabled = true
	case "disable":
		if _, err := qwdttHydraCommand("disable", p.HydraProxyName, p.HydraPolicy); err != nil {
			http.Error(w, err.Error(), 500)
			return
		}
		p.HydraFailoverEnabled = false
	default:
		http.Error(w, "action must be enable or disable", 400)
		return
	}
	a.mu.Lock()
	for i := range a.store.Profiles {
		if a.store.Profiles[i].ID == p.ID {
			a.store.Profiles[i] = *p
			break
		}
	}
	err := a.save()
	a.mu.Unlock()
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	jsonOut(w, map[string]any{"ok": true, "enabled": p.HydraFailoverEnabled, "active": req.Action == "enable" && false})
}

func (a *App) profileSave(w http.ResponseWriter, r *http.Request) {
	var p Profile
	if err := body(w, r, &p); err != nil {
		http.Error(w, "bad json", 400)
		return
	}
	if p.ID == "" {
		p.ID = newID()
	}
	// Profile POST is also used for partial UI updates (for example moving a
	// profile to a folder). Preserve all existing secrets and VK role choices
	// before applying defaults, otherwise a partial update could silently turn
	// VK-2 back into the default backup account.
	a.mu.Lock()
	var oldProfile *Profile
	for i := range a.store.Profiles {
		if a.store.Profiles[i].ID == p.ID {
			cp := a.store.Profiles[i]
			oldProfile = &cp
			break
		}
	}
	a.mu.Unlock()
	if oldProfile != nil {
		if p.Name == "" {
			p.Name = oldProfile.Name
		}
		if p.ServerID == "" {
			p.ServerID = oldProfile.ServerID
		}
		if p.Mode == "" {
			p.Mode = oldProfile.Mode
		}
		if p.VKHashes == "" {
			p.VKHashes = oldProfile.VKHashes
		}
		if p.VKAccessToken == "" {
			p.VKAccessToken = oldProfile.VKAccessToken
		}
		if p.VKAccount1Token == "" {
			p.VKAccount1Token = oldProfile.VKAccount1Token
		}
		if p.VKAccount2Token == "" {
			p.VKAccount2Token = oldProfile.VKAccount2Token
		}
		if p.VKAccount1Name == "" {
			p.VKAccount1Name = oldProfile.VKAccount1Name
		}
		if p.VKAccount2Name == "" {
			p.VKAccount2Name = oldProfile.VKAccount2Name
		}
		if p.VKPrimaryID == "" {
			p.VKPrimaryID = oldProfile.VKPrimaryID
		}
		if p.VKBackupID == "" {
			p.VKBackupID = oldProfile.VKBackupID
		}
		if p.Password == "" {
			p.Password = oldProfile.Password
		}
		if p.ListenPort == 0 {
			p.ListenPort = oldProfile.ListenPort
		}
		if p.Workers == 0 {
			p.Workers = oldProfile.Workers
		}
		if p.FolderID == "" {
			p.FolderID = oldProfile.FolderID
		}
		if p.HydraProxyName == "" {
			p.HydraProxyName = oldProfile.HydraProxyName
		}
		if p.HydraPolicy == "" {
			p.HydraPolicy = oldProfile.HydraPolicy
		}
		if !p.VKAccount {
			p.VKAccount = oldProfile.VKAccount
		}
	}
	if p.Workers < 1 {
		p.Workers = 1
	}
	if p.Workers > 4 {
		p.Workers = 4
	}
	if p.Mode != "" && p.Mode != "wg" && p.Mode != "raw" && p.Mode != "socks5" {
		p.Mode = "raw"
	}
	if p.ListenPort <= 0 {
		p.ListenPort = 1301
	}
	if p.HydraPolicy == "" {
		p.HydraPolicy = "Policy0"
	}
	if p.UseGlobalHashes {
		p.VKHashes = ""
	}
	if p.VKAccount1Name == "" {
		p.VKAccount1Name = "VK-1"
	}
	if p.VKAccount2Name == "" {
		p.VKAccount2Name = "VK-2"
	}
	if p.VKPrimaryID != "1" && p.VKPrimaryID != "2" {
		p.VKPrimaryID = "1"
	}
	if p.VKBackupID != "1" && p.VKBackupID != "2" {
		p.VKBackupID = "2"
	}
	if p.VKPrimaryID == p.VKBackupID {
		p.VKBackupID = map[string]string{"1": "2", "2": "1"}[p.VKPrimaryID]
	}
	if p.VKAccount1Token != "" || p.VKAccount2Token != "" {
		p.VKAccount = true
	}
	if p.Mode != "socks5" && p.Mode != "socks" && p.Mode != "" {
		p.HydraFailoverEnabled = false
	}
	a.mu.Lock()
	found := false
	for i := range a.store.Profiles {
		if a.store.Profiles[i].ID == p.ID {
			old := a.store.Profiles[i]
			if !p.VKAccount && (old.VKAccount1Token != "" || old.VKAccount2Token != "") {
				p.VKAccount = true
			}
			a.store.Profiles[i] = p
			found = true
			break
		}
	}
	if !found {
		a.store.Profiles = append(a.store.Profiles, p)
	}
	if err := a.save(); err != nil {
		a.mu.Unlock()
		http.Error(w, err.Error(), 500)
		return
	}
	a.mu.Unlock()
	if p.Mode == "socks5" || p.Mode == "socks" || p.Mode == "" {
		syncKeeneticSOCKS5(p.ListenPort)
	}
	// Keep the on-disk failover controller synchronized with the panel setting.
	// Enabling arms automatic failover; disabling is always a manual action and
	// therefore also clears a latched HydraRoute route.
	if p.HydraFailoverEnabled && (p.Mode == "socks5" || p.Mode == "socks" || p.Mode == "") {
		if _, err := qwdttHydraCommand("arm", p.HydraProxyName, p.HydraPolicy); err != nil {
			appendWebEvent(fmt.Sprintf("HydraRoute failover arm failed: %v", err))
		}
	} else if !p.HydraFailoverEnabled || !(p.Mode == "socks5" || p.Mode == "socks" || p.Mode == "") {
		// Changing a profile away from SOCKS5 is also a manual disable: never
		// leave a latched HydraRoute policy behind when the feature is no longer
		// applicable to the profile.
		if _, err := qwdttHydraCommand("disable", p.HydraProxyName, p.HydraPolicy); err != nil {
			appendWebEvent(fmt.Sprintf("HydraRoute failover disable failed: %v", err))
		}
	}
	jsonOut(w, p)
}
func (a *App) telegram(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if r.Method == "GET" {
		out := make([]TelegramRecipientPublic, 0, len(a.store.Telegram))
		for _, x := range a.store.Telegram {
			out = append(out, TelegramRecipientPublic{ID: x.ID, Name: x.Name, ChatID: x.ChatID, Enabled: x.Enabled, Configured: x.BotToken != ""})
		}
		jsonOut(w, out)
		return
	}
	if r.Method == "DELETE" {
		id := r.URL.Query().Get("id")
		for i, x := range a.store.Telegram {
			if x.ID == id {
				a.store.Telegram = append(a.store.Telegram[:i], a.store.Telegram[i+1:]...)
				_ = a.save()
				jsonOut(w, map[string]any{"ok": true})
				return
			}
		}
		http.Error(w, "telegram recipient not found", 404)
		return
	}
	var x TelegramRecipient
	if err := body(w, r, &x); err != nil {
		http.Error(w, "bad json", 400)
		return
	}
	if x.ID == "" {
		x.ID = newID()
	}
	x.Name = strings.TrimSpace(x.Name)
	x.ChatID = strings.TrimSpace(x.ChatID)
	x.BotToken = strings.TrimSpace(x.BotToken)
	if x.Name == "" {
		x.Name = "Telegram #" + strconv.Itoa(len(a.store.Telegram)+1)
	}
	for i := range a.store.Telegram {
		if a.store.Telegram[i].ID == x.ID {
			old := a.store.Telegram[i]
			if x.BotToken == "" {
				x.BotToken = old.BotToken
			}
			if x.ChatID == "" {
				x.ChatID = old.ChatID
			}
			if x.Name == "" {
				x.Name = old.Name
			}
			a.store.Telegram[i] = x
			if err := a.save(); err != nil {
				http.Error(w, err.Error(), 500)
				return
			}
			jsonOut(w, map[string]any{"ok": true, "id": x.ID})
			return
		}
	}
	if x.BotToken == "" || x.ChatID == "" {
		http.Error(w, "bot_token and chat_id required", 400)
		return
	}
	a.store.Telegram = append(a.store.Telegram, x)
	if err := a.save(); err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	jsonOut(w, map[string]any{"ok": true, "id": x.ID})
}

func (a *App) telegramTest(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "POST required", 405)
		return
	}
	a.mu.Lock()
	xs := append([]TelegramRecipient(nil), a.store.Telegram...)
	a.mu.Unlock()
	results := map[string]string{}
	client := &http.Client{Timeout: 5 * time.Second}
	for _, x := range xs {
		if !x.Enabled || x.BotToken == "" || x.ChatID == "" {
			results[x.ID] = "disabled/unconfigured"
			continue
		}
		form := url.Values{}
		form.Set("chat_id", x.ChatID)
		form.Set("text", "🧪 qWDTT: тестовое уведомление Telegram\nКанал связи работает. qWDTT не зависит от Telegram.")
		form.Set("disable_web_page_preview", "true")
		req, _ := http.NewRequest(http.MethodPost, "https://api.telegram.org/bot"+x.BotToken+"/sendMessage", strings.NewReader(form.Encode()))
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
		resp, err := client.Do(req)
		if err != nil {
			results[x.ID] = err.Error()
			continue
		}
		resp.Body.Close()
		if resp.StatusCode >= 200 && resp.StatusCode < 300 {
			results[x.ID] = "ok"
		} else {
			results[x.ID] = fmt.Sprintf("HTTP %d", resp.StatusCode)
		}
	}
	jsonOut(w, map[string]any{"results": results})
}

func (a *App) bypass(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if r.Method == "GET" {
		jsonOut(w, a.store.Bypass)
		return
	}
	var b Bypass
	if err := body(w, r, &b); err != nil {
		http.Error(w, "bad json", 400)
		return
	}
	if len(b.Rules) > 100 {
		b.Rules = b.Rules[:100]
	}
	a.store.Bypass = b
	if err := a.save(); err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	jsonOut(w, b)
}

func (a *App) sshClient(s Server) (*ssh.Client, error) {
	var auth ssh.AuthMethod
	if s.UseKey && strings.TrimSpace(s.SSHKey) != "" {
		var signer ssh.Signer
		var err error
		if s.SSHKeyPassphrase != "" {
			signer, err = ssh.ParsePrivateKeyWithPassphrase([]byte(s.SSHKey), []byte(s.SSHKeyPassphrase))
		} else {
			signer, err = ssh.ParsePrivateKey([]byte(s.SSHKey))
		}
		if err != nil {
			return nil, err
		}
		auth = ssh.PublicKeys(signer)
	} else {
		auth = ssh.Password(s.SSHPassword)
	}
	c, err := ssh.Dial("tcp", net.JoinHostPort(s.Host, strconv.Itoa(s.SSHPort)), &ssh.ClientConfig{User: s.SSHUser, Auth: []ssh.AuthMethod{auth}, HostKeyCallback: ssh.InsecureIgnoreHostKey(), Timeout: 15 * time.Second})
	return c, err
}
func runSSH(client *ssh.Client, command string) (string, error) {
	sess, err := client.NewSession()
	if err != nil {
		return "", err
	}
	defer sess.Close()
	out, err := sess.CombinedOutput(command)
	return string(out), err
}
func copyStream(client *ssh.Client, remote string, data []byte, mode string) error {
	sess, err := client.NewSession()
	if err != nil {
		return err
	}
	defer sess.Close()
	cmd := fmt.Sprintf("umask 077; cat > %s; chmod %s %s", shell(remote), mode, shell(remote))
	in, err := sess.StdinPipe()
	if err != nil {
		return err
	}
	if err := sess.Start(cmd); err != nil {
		return err
	}
	_, _ = in.Write(data)
	_ = in.Close()
	return sess.Wait()
}
func shell(s string) string { return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'" }

func adminPort(s Server) int {
	if s.AdminPort > 0 {
		return s.AdminPort
	}
	return 56102
}

func (a *App) deploy(w http.ResponseWriter, r *http.Request) {
	var req struct {
		ServerID string `json:"server_id"`
	}
	if err := body(w, r, &req); err != nil {
		http.Error(w, "bad json", 400)
		return
	}
	a.mu.Lock()
	var s *Server
	for i := range a.store.Servers {
		if a.store.Servers[i].ID == req.ServerID {
			s = &a.store.Servers[i]
			break
		}
	}
	if s == nil {
		a.mu.Unlock()
		http.Error(w, "server not found", 404)
		return
	}
	copyS := *s
	a.mu.Unlock()
	job := &DeployJob{ID: newID(), ServerID: copyS.ID, State: "running", Progress: 2, Step: "Подключение..."}
	a.mu.Lock()
	a.deploy[job.ID] = job
	a.mu.Unlock()
	go a.doDeploy(job, copyS)
	jsonOut(w, job)
}
func (a *App) doDeploy(job *DeployJob, s Server) {
	set := func(p int, step string) { a.mu.Lock(); job.Progress = p; job.Step = step; a.mu.Unlock() }
	client, err := a.sshClient(s)
	if err != nil {
		set(100, "Ошибка SSH")
		job.Error = err.Error()
		job.State = "failed"
		return
	}
	defer client.Close()
	set(8, "Подготовка файлов...")
	script, err := os.ReadFile(filepath.Join(a.root, "deploy", "deploy.sh"))
	if err != nil {
		job.State = "failed"
		job.Error = err.Error()
		return
	}
	// The Android release contains deploy.sh but not the generated server asset. Entware deployment therefore looks for a locally staged server binary.
	serverPath := filepath.Join(a.root, "deploy", "wdtt-server")
	server, err := os.ReadFile(serverPath)
	if err != nil {
		job.State = "failed"
		job.Error = "wdtt-server asset is missing: " + err.Error()
		return
	}
	set(15, "Загрузка deploy.sh...")
	if err := copyStream(client, "/tmp/deploy.sh", script, "700"); err != nil {
		job.State = "failed"
		job.Error = err.Error()
		return
	}
	set(30, "Загрузка wdtt-server...")
	if err := copyStream(client, "/tmp/wdtt-server", server, "700"); err != nil {
		job.State = "failed"
		job.Error = err.Error()
		return
	}
	dns := s.DNS1
	if dns == "" {
		dns = "1.1.1.1"
	}
	if s.DNS2 != "" {
		dns += "," + s.DNS2
	}
	adminID := ""
	adminToken := s.AdminToken
	if adminToken == "" {
		adminToken = newID() + newID()
	}
	mainPassword := s.MainPassword
	if mainPassword == "" {
		mainPassword = newID() + newID()
	}
	set(38, "Загрузка секретов...")
	if err := copyStream(client, "/tmp/wdtt-admin.token", []byte(adminToken+"\n"), "600"); err != nil {
		job.State = "failed"
		job.Error = "admin token upload: " + err.Error()
		return
	}
	if err := copyStream(client, "/tmp/wdtt-main.password", []byte(mainPassword+"\n"), "600"); err != nil {
		job.State = "failed"
		job.Error = "main password upload: " + err.Error()
		return
	}
	if s.BotToken != "" {
		if err := copyStream(client, "/tmp/wdtt-bot.token", []byte(s.BotToken+"\n"), "600"); err != nil {
			job.State = "failed"
			job.Error = "bot token upload: " + err.Error()
			return
		}
	}
	env := fmt.Sprintf("WDTT_DNS_SERVERS=%s WDTT_DTLS_PORT=%d WDTT_WG_PORT=%d WDTT_SSH_PORT=%d WDTT_ADMIN_PORT=%d WDTT_ADMIN_ID=%s", shell(dns), s.DTLS, s.WG, s.SSHPort, adminPort(s), shell(adminID))
	if s.ManualPorts && s.Direct > 0 {
		env += fmt.Sprintf(" WDTT_DIRECT_PORT=%d", s.Direct)
	}
	if s.ManualPorts && s.Raw > 0 {
		env += fmt.Sprintf(" WDTT_RAW_PORT=%d", s.Raw)
	}
	cmd := fmt.Sprintf("chmod 600 /tmp/wdtt-admin.token /tmp/wdtt-main.password /tmp/deploy.sh /tmp/wdtt-server; %s bash /tmp/deploy.sh", env)
	set(50, "Установка...")
	out, err := runSSH(client, cmd)
	a.mu.Lock()
	job.Output = out
	a.mu.Unlock()
	if err != nil {
		job.State = "failed"
		job.Error = err.Error()
		return
	}
	if !strings.Contains(out, "WDTT_DEPLOY_OK") {
		job.State = "failed"
		job.Error = "WDTT_DEPLOY_OK не найден в выводе deploy.sh"
		return
	}
	a.mu.Lock()
	for i := range a.store.Servers {
		if a.store.Servers[i].ID == s.ID {
			a.store.Servers[i].Installed = true
			a.store.Servers[i].AdminToken = adminToken
			a.store.Servers[i].MainPassword = mainPassword
			a.store.Servers[i].LastDeploy = time.Now().Format(time.RFC3339)
			if pin := parseAdminPin(out); pin != "" {
				a.store.Servers[i].AdminPin = pin
			}
			break
		}
	}
	_ = a.save()
	job.Progress = 100
	job.Step = "Готово"
	job.State = "success"
	a.mu.Unlock()
}
func parseAdminPin(out string) string {
	for _, line := range strings.Split(out, "\n") {
		if strings.HasPrefix(strings.TrimSpace(line), "WDTT_ADMIN_PIN|") {
			return strings.TrimSpace(line)[len("WDTT_ADMIN_PIN|"):]
		}
	}
	return ""
}

func (a *App) uninstall(w http.ResponseWriter, r *http.Request) {
	var req struct {
		ServerID string `json:"server_id"`
	}
	if err := body(w, r, &req); err != nil {
		http.Error(w, "bad json", 400)
		return
	}
	a.mu.Lock()
	var s *Server
	for i := range a.store.Servers {
		if a.store.Servers[i].ID == req.ServerID {
			cp := a.store.Servers[i]
			s = &cp
			break
		}
	}
	a.mu.Unlock()
	if s == nil {
		http.Error(w, "server not found", 404)
		return
	}
	client, err := a.sshClient(*s)
	if err != nil {
		http.Error(w, err.Error(), 502)
		return
	}
	defer client.Close()
	dns := s.DNS1
	if dns == "" {
		dns = "1.1.1.1"
	}
	if s.DNS2 != "" {
		dns += "," + s.DNS2
	}
	cmd := fmt.Sprintf("WDTT_DNS_SERVERS=%s WDTT_DTLS_PORT=%d WDTT_WG_PORT=%d WDTT_SSH_PORT=%d WDTT_ADMIN_PORT=%d bash /tmp/deploy.sh --uninstall", shell(dns), s.DTLS, s.WG, s.SSHPort, adminPort(*s))
	out, err := runSSH(client, cmd)
	if err != nil {
		http.Error(w, out+"\n"+err.Error(), 502)
		return
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	for i := range a.store.Servers {
		if a.store.Servers[i].ID == s.ID {
			a.store.Servers[i].Installed = false
			a.store.Servers[i].AdminPin = ""
			_ = a.save()
			break
		}
	}
	jsonOut(w, map[string]any{"ok": true, "output": out})
}

func (a *App) serverStatus(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	a.mu.Lock()
	var s *Server
	for i := range a.store.Servers {
		if a.store.Servers[i].ID == id {
			cp := a.store.Servers[i]
			s = &cp
			break
		}
	}
	a.mu.Unlock()
	if s == nil {
		http.Error(w, "server not found", 404)
		return
	}
	client, err := a.sshClient(*s)
	if err != nil {
		jsonOut(w, map[string]any{"reachable": false, "error": err.Error()})
		return
	}
	defer client.Close()
	out, err := runSSH(client, "systemctl is-active wdtt-entware 2>/dev/null || true; test -x /usr/local/bin/wdtt-server-entware && echo BINARY_OK || echo BINARY_MISSING; ip link show wdtt-ent0 >/dev/null 2>&1 && echo TUN_OK || echo TUN_MISSING")
	jsonOut(w, map[string]any{"reachable": err == nil, "installed": strings.Contains(out, "BINARY_OK"), "active": strings.Contains(out, "active"), "tun": strings.Contains(out, "TUN_OK"), "output": out, "error": errString(err)})
}
func subtleConstantTimeEqual(a, b string) bool {
	if len(a) != len(b) {
		return false
	}
	return subtle.ConstantTimeCompare([]byte(a), []byte(b)) == 1
}

func errString(err error) string {
	if err == nil {
		return ""
	}
	return err.Error()
}

func (a *App) jobs(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	defer a.mu.Unlock()
	jsonOut(w, a.deploy)
}

type TunnelProcess struct {
	mu               sync.Mutex
	cmd              *exec.Cmd
	profileID        string
	startedAt        time.Time
	logPath          string
	stopping         bool
	recoverAfterStop bool
}

func (a *App) tunnelStatus(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	tp := a.tunnel
	if tp == nil || tp.cmd == nil || tp.cmd.Process == nil {
		a.mu.Unlock()
		jsonOut(w, map[string]any{"running": false})
		return
	}
	pid := tp.cmd.Process.Pid
	profileID := tp.profileID
	started := tp.startedAt
	a.mu.Unlock()
	// Signal 0 is a cheap liveness check on Unix.
	running := tp.cmd.Process.Signal(syscall.Signal(0)) == nil
	jsonOut(w, map[string]any{"running": running, "pid": pid, "profile_id": profileID, "started_at": started.Format(time.RFC3339)})
}

func (a *App) telegramRuntimeConfig() []map[string]any {
	out := []map[string]any{}
	for _, x := range a.store.Telegram {
		if !x.Enabled || x.BotToken == "" || x.ChatID == "" {
			continue
		}
		out = append(out, map[string]any{"id": x.ID, "name": x.Name, "bot_token": x.BotToken, "chat_id": x.ChatID, "enabled": true})
	}
	return out
}

const qwdttFailoverWatchState = "/opt/etc/qwdtt/failover-watch.conf"

func loadQWDTTFailoverWatch() (profileID string, badSince int64, intentionalStop bool) {
	b, err := os.ReadFile(qwdttFailoverWatchState)
	if err != nil {
		return "", 0, false
	}
	for _, line := range strings.Split(string(b), "\n") {
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		switch parts[0] {
		case "PROFILE_ID":
			profileID = parts[1]
		case "BAD_SINCE":
			badSince, _ = strconv.ParseInt(parts[1], 10, 64)
		case "INTENTIONAL_STOP":
			intentionalStop = strings.TrimSpace(parts[1]) == "1"
		}
	}
	return
}

func saveQWDTTFailoverWatch(profileID string, badSince int64, intentionalStop bool) {
	_ = os.MkdirAll(filepath.Dir(qwdttFailoverWatchState), 0700)
	tmp := qwdttFailoverWatchState + ".tmp"
	data := fmt.Sprintf("PROFILE_ID=%s\nBAD_SINCE=%d\nINTENTIONAL_STOP=%d\n", profileID, badSince, boolInt(intentionalStop))
	if os.WriteFile(tmp, []byte(data), 0600) == nil {
		_ = os.Rename(tmp, qwdttFailoverWatchState)
	}
}

func clearQWDTTFailoverDowntime() {
	profileID, _, intentional := loadQWDTTFailoverWatch()
	if profileID != "" {
		saveQWDTTFailoverWatch(profileID, 0, intentional)
	}
}

func boolInt(v bool) int {
	if v {
		return 1
	}
	return 0
}

func markQWDTTManualStop() {
	profileID, _, _ := loadQWDTTFailoverWatch()
	if profileID != "" {
		saveQWDTTFailoverWatch(profileID, 0, true)
	}
}

func markQWDTTStarted(profileID string) {
	saveQWDTTFailoverWatch(profileID, 0, false)
}

func (a *App) startTunnelProfile(profileID string) (int, error) {
	a.mu.Lock()
	if a.tunnel != nil && a.tunnel.cmd != nil && a.tunnel.cmd.Process != nil && a.tunnel.cmd.Process.Signal(syscall.Signal(0)) == nil {
		a.mu.Unlock()
		return 0, errors.New("tunnel already running")
	}
	var p *Profile
	for i := range a.store.Profiles {
		if a.store.Profiles[i].ID == profileID {
			cp := a.store.Profiles[i]
			p = &cp
			break
		}
	}
	if p == nil {
		a.mu.Unlock()
		return 0, errors.New("profile not found")
	}
	var sv *Server
	for i := range a.store.Servers {
		if a.store.Servers[i].ID == p.ServerID {
			cp := a.store.Servers[i]
			sv = &cp
			break
		}
	}
	if sv == nil {
		a.mu.Unlock()
		return 0, errors.New("profile server not found")
	}
	root := a.root
	a.mu.Unlock()

	mode := p.Mode
	if mode == "socks5" {
		mode = "socks"
	} else if mode == "raw" {
		mode = "rawtun"
	} else {
		mode = "vpn"
	}
	peer := net.JoinHostPort(sv.Host, strconv.Itoa(sv.DTLS))
	cfg := map[string]any{
		"mode": mode, "tun_name": "qwdtt0", "gateway_mode": false, "workers": p.Workers,
		"turn_tcp": true, "obfs": "audio", "vk_auth": "anonymous", "vk_hashes": p.VKHashes,
		"vk_access_token": p.VKAccessToken, "vk_primary_id": p.VKPrimaryID, "vk_backup_id": p.VKBackupID,
		"vk_accounts":            []map[string]any{{"id": "1", "name": p.VKAccount1Name, "access_token": p.VKAccount1Token}, {"id": "2", "name": p.VKAccount2Name, "access_token": p.VKAccount2Token}},
		"telegram":               a.telegramRuntimeConfig(),
		"hydra_failover_enabled": p.HydraFailoverEnabled, "hydra_proxy_name": p.HydraProxyName, "hydra_policy": p.HydraPolicy,
		"peer": peer, "password": p.Password, "socks": fmt.Sprintf("192.168.1.1:%d", func() int {
			if p.ListenPort > 0 {
				return p.ListenPort
			}
			return 1301
		}()), "go_dns": "router",
	}
	if p.VKAccount {
		cfg["vk_auth"] = "account"
	}
	if p.Mode == "socks5" || p.Mode == "socks" || p.Mode == "" {
		syncKeeneticSOCKS5(p.ListenPort)
	}
	if p.HydraFailoverEnabled && (p.Mode == "socks5" || p.Mode == "socks" || p.Mode == "") {
		if _, err := qwdttHydraCommand("arm", p.HydraProxyName, p.HydraPolicy); err != nil {
			appendWebEvent(fmt.Sprintf("HydraRoute failover arm failed: %v", err))
		}
	}
	cfgPath := filepath.Join(root, "runtime-profile.json")
	b, _ := json.MarshalIndent(cfg, "", "  ")
	if err := os.WriteFile(cfgPath, b, 0600); err != nil {
		return 0, err
	}
	bin := os.Getenv("QWDTT_CLIENT_BIN")
	if bin == "" {
		bin = "/opt/bin/qwdtt"
	}
	cmd := exec.Command(bin, "-entware-config", cfgPath)
	logPath := filepath.Join(root, "..", "logs", "qwdtt.log")
	_ = os.MkdirAll(filepath.Dir(logPath), 0700)
	lf, err := os.OpenFile(logPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0600)
	if err != nil {
		return 0, err
	}
	cmd.Stdout, cmd.Stderr = lf, lf
	if err := cmd.Start(); err != nil {
		lf.Close()
		return 0, err
	}
	a.mu.Lock()
	a.tunnel = &TunnelProcess{cmd: cmd, profileID: p.ID, startedAt: time.Now(), logPath: logPath}
	a.mu.Unlock()
	markQWDTTStarted(p.ID)
	go func() {
		err := cmd.Wait()
		lf.Close()
		a.mu.Lock()
		cur := a.tunnel
		if cur != nil && cur.cmd == cmd {
			intentional := cur.stopping
			recoverAfterStop := cur.recoverAfterStop
			pid := cmd.Process.Pid
			a.tunnel = nil
			a.mu.Unlock()
			if recoverAfterStop || !intentional {
				if intentional {
					appendWebEvent(fmt.Sprintf("tunnel health restart completed for pid %d: %v", pid, err))
				} else {
					appendWebEvent(fmt.Sprintf("tunnel pid %d exited unexpectedly: %v", pid, err))
				}
				go a.autoRecoverTunnel(p.ID)
			}
		} else {
			a.mu.Unlock()
		}
	}()
	appendWebEvent(fmt.Sprintf("tunnel started profile=%s pid=%d", p.ID, cmd.Process.Pid))
	return cmd.Process.Pid, nil
}

func (a *App) tunnelStart(w http.ResponseWriter, r *http.Request) {
	var req struct {
		ProfileID string `json:"profile_id"`
	}
	if err := body(w, r, &req); err != nil || req.ProfileID == "" {
		http.Error(w, "profile_id required", 400)
		return
	}
	pid, err := a.startTunnelProfile(req.ProfileID)
	if err != nil {
		code := 500
		if err.Error() == "tunnel already running" {
			code = 409
		}
		if err.Error() == "profile not found" || err.Error() == "profile server not found" {
			code = 404
		}
		http.Error(w, err.Error(), code)
		return
	}
	jsonOut(w, map[string]any{"ok": true, "pid": pid, "profile_id": req.ProfileID, "auto_restart": true})
}

func (a *App) tunnelHealthWatchdog() {
	t := time.NewTicker(30 * time.Second)
	defer t.Stop()
	lastFailureNotice := map[string]time.Time{}
	wanDownNotified := false
	for range t.C {
		// The monitored profile is persisted so a qWDTT process/web-panel crash
		// cannot reset the five-minute failover clock.
		watchProfile, badUnix, intentionalStop := loadQWDTTFailoverWatch()

		a.mu.Lock()
		cur := a.tunnel
		var profile string
		var mode string
		var port int
		var hydraEnabled bool
		var hydraProxy, hydraPolicy string
		if cur != nil && cur.cmd != nil && cur.cmd.Process != nil {
			profile = cur.profileID
		} else {
			profile = watchProfile
		}
		for _, p := range a.store.Profiles {
			if p.ID == profile {
				mode = p.Mode
				port = p.ListenPort
				hydraEnabled = p.HydraFailoverEnabled
				hydraProxy, hydraPolicy = p.HydraProxyName, p.HydraPolicy
				break
			}
		}
		a.mu.Unlock()

		if profile == "" || !hydraEnabled || !(mode == "socks5" || mode == "socks" || mode == "") {
			continue
		}

		// Once HydraRoute is latched, never automatically fail back. The panel
		// switch is the only way to leave the emergency route.
		if out, err := qwdttHydraCommand("status", hydraProxy, hydraPolicy); err == nil && strings.Contains(out, "FAILOVER_ACTIVE=1") {
			if badUnix != 0 {
				saveQWDTTFailoverWatch(profile, 0, intentionalStop)
			}
			continue
		}

		if intentionalStop {
			// A user-requested stop must never trigger emergency failover.
			continue
		}

		// Physical WAN/LTE loss is not a qWDTT failure. Pause the clock while
		// the underlying WAN route is unavailable.
		if !wanLikelyUp() {
			if !wanDownNotified {
				appendWebEvent("WAN/LTE appears down; qWDTT failover timer paused")
				wanDownNotified = true
			}
			continue
		}
		if wanDownNotified {
			appendWebEvent("WAN/LTE route restored; qWDTT failover timer resumed")
			wanDownNotified = false
		}

		ok := false
		if cur != nil && cur.cmd != nil && cur.cmd.Process != nil && aProcessAlive(cur.cmd.Process.Pid) {
			if mode == "socks5" || mode == "socks" || mode == "" {
				if port == 0 {
					port = 1301
				}
				ok = socks5ConnectivityProbe(net.JoinHostPort("192.168.1.1", strconv.Itoa(port)), "1.1.1.1:443", 4*time.Second)
			} else {
				ok = clientHeartbeatHealthy(45 * time.Second)
				if !ok {
					ok = ifacePresent("qwdtt0") && tcpReachable("1.1.1.1:443", 3*time.Second)
				}
			}
		}

		if ok {
			if badUnix != 0 {
				appendWebEvent(fmt.Sprintf("qWDTT connection recovered before 5-minute failover window: profile=%s", profile))
			}
			saveQWDTTFailoverWatch(profile, 0, false)
			continue
		}

		if badUnix == 0 {
			badUnix = time.Now().Unix()
			saveQWDTTFailoverWatch(profile, badUnix, false)
			appendWebEvent(fmt.Sprintf("qWDTT connection lost; five-minute HydraRoute failover timer started: profile=%s", profile))
		}
		elapsed := time.Since(time.Unix(badUnix, 0))
		if elapsed < 5*time.Minute {
			continue
		}
		if last, ok := lastFailureNotice[profile]; ok && time.Since(last) < 5*time.Minute {
			continue
		}
		lastFailureNotice[profile] = time.Now()
		if _, err := qwdttHydraCommand("failover", hydraProxy, hydraPolicy); err != nil {
			appendWebEvent(fmt.Sprintf("qWDTT failed continuously for %s; HydraRoute failover attempt failed: %v", elapsed.Round(time.Second), err))
		} else {
			appendWebEvent(fmt.Sprintf("qWDTT failed continuously for %s; HydraRoute failover activated and latched", elapsed.Round(time.Second)))
			saveQWDTTFailoverWatch(profile, 0, false)
		}
	}
}

func appendWebEvent(msg string) {
	path := "/opt/etc/qwdtt/events.log"
	_ = os.MkdirAll(filepath.Dir(path), 0700)
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = fmt.Fprintf(f, "%s %s\n", time.Now().Format(time.RFC3339), msg)
	if st, err := f.Stat(); err == nil && st.Size() > 512*1024 {
		_ = os.Rename(path, path+".1")
	}
}

func (a *App) autoRecoverTunnel(profileID string) {
	for attempt := 1; attempt <= 5; attempt++ {
		time.Sleep(time.Duration(attempt) * 2 * time.Second)
		if _, err := a.startTunnelProfile(profileID); err == nil {
			appendWebEvent(fmt.Sprintf("tunnel auto-recovered profile=%s attempt=%d", profileID, attempt))
			return
		}
	}
	appendWebEvent(fmt.Sprintf("tunnel auto-recovery failed profile=%s after 5 attempts", profileID))
}

func (a *App) tunnelProcessWatchdog() {
	t := time.NewTicker(15 * time.Second)
	defer t.Stop()
	for range t.C {
		a.mu.Lock()
		cur := a.tunnel
		if cur != nil && cur.cmd != nil && cur.cmd.Process != nil {
			if cur.cmd.Process.Signal(syscall.Signal(0)) != nil && !cur.stopping {
				profile := cur.profileID
				a.mu.Unlock()
				go a.autoRecoverTunnel(profile)
				continue
			}
		}
		a.mu.Unlock()
	}
}

func (a *App) tunnelStop(w http.ResponseWriter, r *http.Request) {
	markQWDTTManualStop()
	a.mu.Lock()
	tp := a.tunnel
	if tp != nil {
		tp.stopping = true
	}
	a.mu.Unlock()
	if tp == nil || tp.cmd == nil || tp.cmd.Process == nil {
		jsonOut(w, map[string]any{"ok": true, "running": false})
		return
	}
	_ = tp.cmd.Process.Signal(syscall.SIGTERM)
	jsonOut(w, map[string]any{"ok": true})
}

func (a *App) tunnelRestart(w http.ResponseWriter, r *http.Request) {
	// Stop first; caller can start the same profile explicitly. This endpoint is kept simple and deterministic.
	a.tunnelStop(w, r)
}

func wanLikelyUp() bool {
	b, err := os.ReadFile("/proc/net/route")
	if err != nil {
		return true // fail open: inability to inspect WAN must not restart qWDTT
	}
	for _, line := range strings.Split(string(b), "\n") {
		fields := strings.Fields(line)
		if len(fields) < 4 || fields[0] == "Iface" {
			continue
		}
		if fields[1] != "00000000" {
			continue
		}
		iface := fields[0]
		state, err := os.ReadFile("/sys/class/net/" + iface + "/operstate")
		if err != nil {
			return true
		}
		return strings.TrimSpace(string(state)) != "down"
	}
	return true
}

func socks5ConnectivityProbe(addr, target string, timeout time.Duration) bool {
	c, err := net.DialTimeout("tcp", addr, timeout)
	if err != nil {
		return false
	}
	defer c.Close()
	_ = c.SetDeadline(time.Now().Add(timeout))
	if _, err = c.Write([]byte{0x05, 0x01, 0x00}); err != nil {
		return false
	}
	resp := make([]byte, 2)
	if _, err = io.ReadFull(c, resp); err != nil || resp[0] != 0x05 || resp[1] == 0xff {
		return false
	}
	host, portStr, err := net.SplitHostPort(target)
	if err != nil {
		return false
	}
	portNum, err := strconv.Atoi(portStr)
	if err != nil || portNum < 1 || portNum > 65535 {
		return false
	}
	ip := net.ParseIP(host)
	var req []byte
	if ip4 := ip.To4(); ip4 != nil {
		req = append([]byte{0x05, 0x01, 0x00, 0x01}, ip4...)
	} else if ip16 := ip.To16(); ip16 != nil {
		req = append([]byte{0x05, 0x01, 0x00, 0x04}, ip16...)
	} else {
		if len(host) > 255 {
			return false
		}
		req = append([]byte{0x05, 0x01, 0x00, 0x03, byte(len(host))}, []byte(host)...)
	}
	req = append(req, byte(portNum>>8), byte(portNum))
	if _, err = c.Write(req); err != nil {
		return false
	}
	reply := make([]byte, 4)
	if _, err = io.ReadFull(c, reply); err != nil || reply[0] != 0x05 || reply[1] != 0x00 {
		return false
	}
	switch reply[3] {
	case 0x01:
		_, err = io.CopyN(io.Discard, c, 4+2)
	case 0x03:
		var n [1]byte
		if _, err = io.ReadFull(c, n[:]); err == nil {
			_, err = io.CopyN(io.Discard, c, int64(n[0])+2)
		}
	case 0x04:
		_, err = io.CopyN(io.Discard, c, 16+2)
	default:
		return false
	}
	return err == nil
}

type clientHealthFile struct {
	UpdatedAt         int64 `json:"updated_at"`
	LastTraffic       int64 `json:"last_traffic"`
	LastSession       int64 `json:"last_session"`
	ActiveConnections int32 `json:"active_connections"`
}

func clientHeartbeatHealthy(maxAge time.Duration) bool {
	b, err := os.ReadFile("/opt/etc/qwdtt/client-health.json")
	if err != nil {
		return false
	}
	var h clientHealthFile
	if json.Unmarshal(b, &h) != nil || h.UpdatedAt == 0 {
		return false
	}
	if time.Since(time.Unix(h.UpdatedAt, 0)) > maxAge {
		return false
	}
	// A fresh heartbeat proves the qWDTT client is alive. Do not require an
	// active session here: during manual CAPTCHA handling the workers can be
	// alive with zero sessions for several minutes, and the watchdog must never
	// restart them in the middle of that recovery. SOCKS mode has a separate
	// true end-to-end connectivity probe above.
}

func ifacePresent(name string) bool {
	_, err := os.Stat("/sys/class/net/" + name)
	return err == nil
}

func ifaceBytes(name, dir string) int64 {
	b, err := os.ReadFile("/sys/class/net/" + name + "/statistics/" + dir + "_bytes")
	if err != nil {
		return -1
	}
	n, _ := strconv.ParseInt(strings.TrimSpace(string(b)), 10, 64)
	return n
}

func tcpReachable(addr string, timeout time.Duration) bool {
	c, err := net.DialTimeout("tcp", addr, timeout)
	if err != nil {
		return false
	}
	_ = c.Close()
	return true
}

func (a *App) tunnelHealth(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	if a.tunnel == nil || a.tunnel.cmd == nil || a.tunnel.cmd.Process == nil {
		a.mu.Unlock()
		jsonOut(w, map[string]any{"running": false, "healthy": false})
		return
	}
	pid := a.tunnel.cmd.Process.Pid
	profileID := a.tunnel.profileID
	var mode string
	var socksPort int
	for _, p := range a.store.Profiles {
		if p.ID == profileID {
			mode = p.Mode
			socksPort = p.ListenPort
			break
		}
	}
	a.mu.Unlock()
	running := aProcessAlive(pid)
	out := map[string]any{"running": running, "pid": pid, "profile_id": profileID, "healthy": running}
	if !running {
		out["healthy"] = false
		jsonOut(w, out)
		return
	}
	if mode == "socks5" || mode == "socks" || mode == "" {
		if socksPort == 0 {
			socksPort = 1301
		}
		ok := tcpReachable(net.JoinHostPort("192.168.1.1", strconv.Itoa(socksPort)), 2*time.Second)
		out["socks"] = ok
		out["healthy"] = ok
	} else {
		tun := "qwdtt0"
		out["interface"] = tun
		out["interface_present"] = ifacePresent(tun)
		out["rx_bytes"] = ifaceBytes(tun, "rx")
		out["tx_bytes"] = ifaceBytes(tun, "tx")
		out["healthy"] = ifacePresent(tun)
	}
	jsonOut(w, out)
}

func aProcessAlive(pid int) bool {
	if pid <= 0 {
		return false
	}
	p, err := os.FindProcess(pid)
	if err != nil {
		return false
	}
	return p.Signal(syscall.Signal(0)) == nil
}

func (a *App) serverAdminHealth(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	a.mu.Lock()
	var s *Server
	for i := range a.store.Servers {
		if a.store.Servers[i].ID == id {
			cp := a.store.Servers[i]
			s = &cp
			break
		}
	}
	a.mu.Unlock()
	if s == nil {
		http.Error(w, "server not found", 404)
		return
	}
	if s.AdminToken == "" {
		jsonOut(w, map[string]any{"reachable": false, "error": "admin token is not configured"})
		return
	}
	port := adminPort(*s)
	host := net.JoinHostPort(s.Host, strconv.Itoa(port))
	tr := &http.Transport{TLSClientConfig: &tls.Config{InsecureSkipVerify: true, MinVersion: tls.VersionTLS12, ServerName: s.Host}}
	client := &http.Client{Transport: tr, Timeout: 8 * time.Second}
	req, _ := http.NewRequest("GET", "https://"+host+"/admin/passwords", nil)
	req.Header.Set("Authorization", "Bearer "+s.AdminToken)
	resp, err := client.Do(req)
	if err != nil {
		jsonOut(w, map[string]any{"reachable": false, "error": err.Error()})
		return
	}
	defer resp.Body.Close()
	certOK := false
	if resp.TLS != nil && len(resp.TLS.PeerCertificates) > 0 && s.AdminPin != "" {
		sum := sha256.Sum256(resp.TLS.PeerCertificates[0].Raw)
		want := strings.TrimSpace(s.AdminPin)
		got := "sha256/" + base64.StdEncoding.EncodeToString(sum[:])
		certOK = subtleConstantTimeEqual(want, got)
	}
	if s.AdminPin != "" && !certOK {
		jsonOut(w, map[string]any{"reachable": true, "http_status": resp.StatusCode, "admin_api": false, "tls_pin_ok": false, "error": "TLS fingerprint mismatch"})
		return
	}
	jsonOut(w, map[string]any{"reachable": true, "http_status": resp.StatusCode, "admin_api": resp.StatusCode == 200, "tls_pin_ok": certOK || s.AdminPin == ""})
}

func (a *App) logsClear(w http.ResponseWriter, r *http.Request) {
	path := filepath.Join(a.root, "..", "logs", "qwdtt.log")
	if err := os.WriteFile(path, []byte{}, 0600); err != nil && !os.IsNotExist(err) {
		http.Error(w, err.Error(), 500)
		return
	}
	jsonOut(w, map[string]any{"ok": true})
}

func (a *App) logs(w http.ResponseWriter, r *http.Request) {
	path := filepath.Join(a.root, "..", "logs", "qwdtt.log")
	f, err := os.Open(path)
	if err != nil && !os.IsNotExist(err) {
		http.Error(w, err.Error(), 500)
		return
	}
	if f == nil {
		fmt.Fprint(w, "")
		return
	}
	defer f.Close()
	b, _ := io.ReadAll(io.LimitReader(f, 200000))
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.Write(b)
}
func (a *App) static(w http.ResponseWriter, r *http.Request) {
	http.ServeFile(w, r, filepath.Join(a.root, "static", "index.html"))
}

func webAuthCredentials() (string, string, bool) {
	b, err := os.ReadFile("/opt/etc/qwdtt/web.auth")
	if err != nil {
		return "", "", false
	}
	line := strings.TrimSpace(string(b))
	parts := strings.SplitN(line, ":", 2)
	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
		return "", "", false
	}
	return parts[0], parts[1], true
}

func (a *App) webPasswordChange(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.Header().Set("Allow", http.MethodPost)
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Current string `json:"current_password"`
		New     string `json:"new_password"`
		Confirm string `json:"confirm_password"`
	}
	if err := body(w, r, &req); err != nil {
		http.Error(w, "bad json", http.StatusBadRequest)
		return
	}
	user, pass, enabled := webAuthCredentials()
	if !enabled {
		http.Error(w, "web authentication is not configured", http.StatusServiceUnavailable)
		return
	}
	if subtle.ConstantTimeCompare([]byte(req.Current), []byte(pass)) != 1 {
		http.Error(w, "current password is incorrect", http.StatusUnauthorized)
		return
	}
	if len(req.New) < 8 {
		http.Error(w, "new password must be at least 8 characters", http.StatusBadRequest)
		return
	}
	if req.New != req.Confirm {
		http.Error(w, "new passwords do not match", http.StatusBadRequest)
		return
	}
	if req.New == req.Current {
		http.Error(w, "new password must differ from current password", http.StatusBadRequest)
		return
	}
	line := user + ":" + req.New + "\n"
	tmp := "/opt/etc/qwdtt/web.auth.tmp"
	if err := os.WriteFile(tmp, []byte(line), 0600); err != nil {
		http.Error(w, "cannot write password file: "+err.Error(), http.StatusInternalServerError)
		return
	}
	if err := os.Rename(tmp, "/opt/etc/qwdtt/web.auth"); err != nil {
		_ = os.Remove(tmp)
		http.Error(w, "cannot replace password file: "+err.Error(), http.StatusInternalServerError)
		return
	}
	jsonOut(w, map[string]any{"ok": true, "user": user})
}

func webBasicAuth(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		user, pass, enabled := webAuthCredentials()
		if !enabled {
			next.ServeHTTP(w, r)
			return
		}
		u, p, ok := r.BasicAuth()
		if !ok || subtle.ConstantTimeCompare([]byte(u), []byte(user)) != 1 || subtle.ConstantTimeCompare([]byte(p), []byte(pass)) != 1 {
			w.Header().Set("WWW-Authenticate", `Basic realm="qWDTT"`)
			http.Error(w, "authentication required", http.StatusUnauthorized)
			return
		}
		next.ServeHTTP(w, r)
	})
}
func main() {
	root := "/opt/etc/qwdtt"
	if v := os.Getenv("QWDTT_ENTWARE_ROOT"); v != "" {
		root = v
	}
	a := &App{root: filepath.Join(root, "web"), cfgPath: filepath.Join(root, "store.json"), deploy: map[string]*DeployJob{}, vkOAuth: map[string]VKOAuthPending{}}
	_ = a.load()
	go a.tunnelProcessWatchdog()
	go a.tunnelHealthWatchdog()
	mux := http.NewServeMux()
	mux.HandleFunc("/api/servers", a.servers)
	mux.HandleFunc("/api/server", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "DELETE" {
			a.serverDelete(w, r)
			return
		}
		a.serverSave(w, r)
	})
	mux.HandleFunc("/api/profiles", a.profiles)
	mux.HandleFunc("/api/web/password", a.webPasswordChange)
	mux.HandleFunc("/api/vk/oauth/start", a.vkOAuthStart)
	mux.HandleFunc("/api/vk/oauth/complete", a.vkOAuthComplete)
	mux.HandleFunc("/vk/callback", a.vkOAuthCallback)
	mux.HandleFunc("/api/profile", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "DELETE" {
			a.profileDelete(w, r)
			return
		}
		a.profileSave(w, r)
	})
	mux.HandleFunc("/api/profiles/export", a.profileExport)
	mux.HandleFunc("/api/profiles/import", a.profileImport)
	mux.HandleFunc("/api/folders", a.folders)
	mux.HandleFunc("/api/folder", a.folderDelete)
	mux.HandleFunc("/api/bypass", a.bypass)
	mux.HandleFunc("/api/deploy", a.deploy)
	mux.HandleFunc("/api/deploy/jobs", a.jobs)
	mux.HandleFunc("/api/deploy/uninstall", a.uninstall)
	mux.HandleFunc("/api/server/status", a.serverStatus)
	mux.HandleFunc("/api/telegram", a.telegram)
	mux.HandleFunc("/api/telegram/test", a.telegramTest)
	mux.HandleFunc("/api/logs", a.logs)
	mux.HandleFunc("/api/logs/clear", a.logsClear)
	mux.HandleFunc("/api/hydra/failover", a.hydraFailover)
	mux.HandleFunc("/api/tunnel/status", a.tunnelStatus)
	mux.HandleFunc("/api/tunnel/health", a.tunnelHealth)
	mux.HandleFunc("/api/tunnel/start", a.tunnelStart)
	mux.HandleFunc("/api/tunnel/stop", a.tunnelStop)
	mux.HandleFunc("/api/tunnel/restart", a.tunnelRestart)
	mux.HandleFunc("/api/server/admin-health", a.serverAdminHealth)
	mux.HandleFunc("/", a.static)
	addr := os.Getenv("QWDTT_WEB_LISTEN")
	if addr == "" {
		addr = "192.168.1.1:18080"
	}
	srv := &http.Server{Addr: addr, Handler: logging(webBasicAuth(mux))}
	fmt.Println("qWDTT Entware web: " + addr)
	if err := srv.ListenAndServe(); err != nil {
		panic(err)
	}
}
func logging(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { start := time.Now(); next.ServeHTTP(w, r); _ = start })
}

var _ = exec.Command
