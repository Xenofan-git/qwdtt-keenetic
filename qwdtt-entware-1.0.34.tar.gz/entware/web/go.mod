module qwdtt-entware-web

go 1.25

require golang.org/x/crypto v0.51.0
