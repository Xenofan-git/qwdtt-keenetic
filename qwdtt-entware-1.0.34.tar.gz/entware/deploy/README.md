# qWDTT Entware deploy

`deploy.sh` is the same installer used by qWDTT Android.

The Entware web panel performs the SSH connection and uploads:
- `/tmp/deploy.sh`
- `/tmp/wdtt-server`

For security and reproducibility, the server binary is intentionally not fabricated. Place the Linux server build at:

`entware/deploy/wdtt-server`

The final Entware package should ship the correct target build(s), normally VPS `linux/amd64` and optionally `linux/arm64`.
