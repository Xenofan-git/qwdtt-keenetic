package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/exec"
	"strings"
	"sync"
	"time"
)

// VKMultiAccountManager keeps exactly two configured VK accounts: a preferred
// (primary) account and a fallback (backup) account. Only one account owns the
// live four-hash worker pool at a time. The inactive account is kept warm in
// its own persistent pool and is promoted only when the current account can no
// longer maintain the active pool.
type VKRuntimeAccount struct {
	ID          string
	Name        string
	AccessToken string
	PoolPath    string
	Failures    map[int]int
	State       string
	LastError   string
	LastChange  time.Time
}

type VKMultiAccountManager struct {
	mu           sync.Mutex
	accounts     map[string]VKRuntimeAccount
	primary      string
	backup       string
	active       string
	tp           *TurnParams
	ctx          context.Context
	hydraEnabled bool
	hydraProxy   string
	hydraPolicy  string
}

var vkAccountsManager = &VKMultiAccountManager{accounts: map[string]VKRuntimeAccount{}}

func normalizeAccountID(id string) string {
	id = strings.TrimSpace(id)
	if id == "" {
		return ""
	}
	return id
}

func accountPoolPath(base, id string) string {
	base = strings.TrimSpace(base)
	if base == "" {
		base = "/opt/etc/qwdtt/vk-pool.json"
	}
	if id == "" || id == "primary" {
		return base
	}
	return base + "." + id
}

func (m *VKMultiAccountManager) configure(ctx context.Context, cfg entwareConfig, tp *TurnParams) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.ctx, m.tp = ctx, tp
	m.hydraEnabled = cfg.HydraFailoverEnabled && (cfg.Mode == "socks5" || cfg.Mode == "socks" || cfg.Mode == "")
	m.hydraProxy = strings.TrimSpace(cfg.HydraProxyName)
	m.hydraPolicy = strings.TrimSpace(cfg.HydraPolicy)
	if m.hydraPolicy == "" {
		m.hydraPolicy = "Policy0"
	}
	m.accounts = map[string]VKRuntimeAccount{}
	for _, a := range cfg.VKAccounts {
		id := normalizeAccountID(a.ID)
		token := strings.TrimSpace(a.AccessToken)
		if id == "" || token == "" {
			continue
		}
		m.accounts[id] = VKRuntimeAccount{ID: id, Name: strings.TrimSpace(a.Name), AccessToken: token, PoolPath: accountPoolPath(cfg.VKPoolState, id), Failures: map[int]int{}, State: "unknown", LastChange: time.Now()}
	}
	m.primary = normalizeAccountID(cfg.VKPrimaryID)
	m.backup = normalizeAccountID(cfg.VKBackupID)
	if m.primary == "" {
		for id := range m.accounts {
			m.primary = id
			break
		}
	}
	if m.backup == "" || m.backup == m.primary {
		for id := range m.accounts {
			if id != m.primary {
				m.backup = id
				break
			}
		}
	}
}

func (m *VKMultiAccountManager) enabled() bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	return len(m.accounts) >= 2 && m.primary != "" && m.backup != ""
}

func (m *VKMultiAccountManager) account(id string) (VKRuntimeAccount, bool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	a, ok := m.accounts[id]
	return a, ok
}

func (m *VKMultiAccountManager) prepare(id string, minActive, minReserve int) ([]string, []string, error) {
	a, ok := m.account(id)
	if !ok {
		return nil, nil, fmt.Errorf("VK account %q is not configured", id)
	}
	ctx := m.ctx
	if ctx == nil {
		return nil, nil, fmt.Errorf("VK account manager is not initialized")
	}

	saved, _ := loadVKPoolState(a.PoolPath, a.AccessToken)
	active := uniqueHashes(saved.Active)
	reserve := uniqueHashes(saved.Reserve)

	// Persisted ACTIVE hashes must be checked before an account is promoted.
	// A JSON file containing 4 stale hashes is not evidence that the account is
	// healthy. Dead hashes are discarded; transient/network/CAPTCHA errors stop
	// preparation so we do not destroy a potentially recoverable pool.
	validated := make([]string, 0, len(active))
	for _, h := range active {
		checkCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
		_, _, _, err := GetCreds(checkCtx, h, 8000+len(validated))
		cancel()
		if err == nil {
			validated = append(validated, h)
			continue
		}
		status, _ := classifyHashCheckError(err)
		if status == "dead" {
			log.Printf("[VK-ACCOUNTS] %s: stale active hash %s... discarded", a.Name, shortHashForLog(h))
			continue
		}
		return validated, reserve, fmt.Errorf("account %s: active hash validation failed: %w", a.Name, err)
	}
	active = validated

	for len(active) < minActive {
		genCtx, cancel := context.WithTimeout(ctx, 25*time.Second)
		h, err := generateVKCallHashGuarded(genCtx, a.AccessToken)
		cancel()
		if err != nil {
			return active, reserve, fmt.Errorf("account %s: create active hash %d/%d: %w", a.Name, len(active)+1, minActive, err)
		}
		if !containsHash(active, h) && !containsHash(reserve, h) {
			// Validate a newly created active hash before committing it.
			checkCtx, checkCancel := context.WithTimeout(ctx, 30*time.Second)
			_, _, _, checkErr := GetCreds(checkCtx, h, 9000+len(active))
			checkCancel()
			if checkErr != nil {
				status, _ := classifyHashCheckError(checkErr)
				if status == "dead" {
					continue
				}
				return active, reserve, fmt.Errorf("account %s: new active hash validation failed: %w", a.Name, checkErr)
			}
			active = append(active, h)
		}
		if len(active) < minActive {
			select {
			case <-time.After(2 * time.Second):
			case <-ctx.Done():
				return active, reserve, ctx.Err()
			}
		}
	}

	// Reserve hashes are validated lazily when promoted. This avoids spending
	// twelve VK lookups at every startup and, importantly, does not turn a
	// temporary CAPTCHA/rate-limit into a false account failure while the four
	// active paths are healthy.
	reserve = uniqueHashes(reserve)
	for len(reserve) < minReserve {
		genCtx, cancel := context.WithTimeout(ctx, 25*time.Second)
		h, err := generateVKCallHashGuarded(genCtx, a.AccessToken)
		cancel()
		if err != nil {
			// Keep the verified active hashes and whatever reserve we managed to
			// create. The next supervisor tick can continue filling the reserve
			// instead of regenerating it from zero.
			_ = saveVKPoolStateAt(a.PoolPath, a.AccessToken, active, reserve)
			return active, reserve, fmt.Errorf("account %s: create reserve hash %d/%d: %w", a.Name, len(reserve)+1, minReserve, err)
		}
		if !containsHash(active, h) && !containsHash(reserve, h) {
			reserve = append(reserve, h)
		}
		if len(reserve) < minReserve {
			select {
			case <-time.After(2 * time.Second):
			case <-ctx.Done():
				return active, reserve, ctx.Err()
			}
		}
	}
	if err := saveVKPoolStateAt(a.PoolPath, a.AccessToken, active, reserve); err != nil {
		return active, reserve, fmt.Errorf("account %s: save pool: %w", a.Name, err)
	}
	return active, reserve, nil
}

func (m *VKMultiAccountManager) applyPool(id string, active, reserve []string) error {
	if len(active) == 0 {
		return fmt.Errorf("VK account %s has no usable hashes", id)
	}
	m.mu.Lock()
	old := m.active
	m.active = id
	tp := m.tp
	acc := m.accounts[id]
	acc.Failures = map[int]int{}
	acc.State = "healthy"
	acc.LastError = ""
	acc.LastChange = time.Now()
	m.accounts[id] = acc
	m.mu.Unlock()
	tp.hashMu.Lock()
	tp.Hashes = append([]string(nil), active...)
	tp.hashMu.Unlock()
	tp.reserveMu.Lock()
	tp.ReserveHashes = append([]string(nil), reserve...)
	tp.reserveMu.Unlock()
	setVKAccessTokenForAccount(acc.AccessToken)
	log.Printf("[VK-ACCOUNTS] Переключение аккаунта: %s -> %s; active=%d reserve=%d", old, id, len(active), len(reserve))
	appendVKEvent(fmt.Sprintf("VK active account changed %s -> %s; active=%d reserve=%d", old, id, len(active), len(reserve)))
	return nil
}

func (m *VKMultiAccountManager) invalidatePool(id string) {
	a, ok := m.account(id)
	if !ok {
		return
	}
	_ = saveVKPoolStateAt(a.PoolPath, a.AccessToken, nil, nil)
	_ = os.Remove(a.PoolPath)
	_ = os.Remove(a.PoolPath + ".tmp")
}

func (m *VKMultiAccountManager) switchTo(id string) error {
	active, reserve, err := m.prepare(id, vkActivePoolSize, vkReserveTarget)
	if err != nil {
		status, _ := classifyHashCheckError(err)
		if len(active) < vkActivePoolSize && status != "captcha" && status != "limited" && status != "network" {
			m.markAccountExhausted(id, err)
		}
		return err
	}
	if err := m.applyPool(id, active, reserve); err != nil {
		return err
	}
	return nil
}

func (m *VKMultiAccountManager) markAccountExhausted(id string, err error) {
	m.mu.Lock()
	if a, ok := m.accounts[id]; ok {
		a.State = "exhausted"
		a.LastError = errStringLocal(err)
		a.LastChange = time.Now()
		m.accounts[id] = a
	}
	m.mu.Unlock()
	m.invalidatePool(id)
}

func (m *VKMultiAccountManager) switchToWithPartialPool(id string) error {
	active, reserve, err := m.prepare(id, vkActivePoolSize, vkReserveTarget)
	if len(active) < vkActivePoolSize {
		if err != nil {
			return err
		}
		return fmt.Errorf("VK account %s has only %d/%d active hashes", id, len(active), vkActivePoolSize)
	}
	if applyErr := m.applyPool(id, active, reserve); applyErr != nil {
		return applyErr
	}
	// A partial reserve is acceptable for an already-working account. The
	// supervisor will keep trying to refill it after CAPTCHA/rate-limit clears.
	return nil
}

func (m *VKMultiAccountManager) setHydraFailover(active bool) {
	m.mu.Lock()
	enabled, proxy, policy := m.hydraEnabled, m.hydraProxy, m.hydraPolicy
	m.mu.Unlock()
	if !enabled {
		return
	}
	args := []string{"failover"}
	if !active {
		args = []string{"recover"}
	}
	cmd := exec.Command("/opt/etc/init.d/S97qwdtt-failover", args...)
	cmd.Env = append(os.Environ(), "HYDRA_PROXY_NAME="+proxy, "HYDRA_POLICY="+policy)
	if out, err := cmd.CombinedOutput(); err != nil {
		log.Printf("[HYDRA-FAILOVER] %s failed: %v: %s", args[0], err, strings.TrimSpace(string(out)))
		return
	}
	if active {
		appendVKEvent("🔴 Все VK аккаунты исчерпаны; трафик переключён на HydraRoute")
	} else {
		appendVKEvent("🟢 VK восстановлен; трафик возвращён с HydraRoute на qWDTT")
	}
}

// noteHashFailure records a failed active slot. We deliberately do not switch
// accounts for a single dead hash: the reserve pool should absorb isolated
// failures. Account failover is allowed only after all four active slots have
// failed and the account cannot replenish them.
func (m *VKMultiAccountManager) noteHashFailure(id string, index int, err error) bool {
	// CAPTCHA, rate-limit and network failures are temporary account-level
	// blocks. Never count them as dead active hashes and never fail over solely
	// because VK asked for a manual challenge.
	status, _ := classifyHashCheckError(err)
	if status == "captcha" || status == "limited" || status == "network" {
		m.mu.Lock()
		if a, ok := m.accounts[id]; ok {
			a.State = status
			a.LastError = errStringLocal(err)
			a.LastChange = time.Now()
			m.accounts[id] = a
		}
		m.mu.Unlock()
		appendVKEvent(fmt.Sprintf("VK account %s temporarily blocked: %s; active hashes are preserved", id, status))
		return false
	}
	m.mu.Lock()
	a, ok := m.accounts[id]
	if !ok {
		m.mu.Unlock()
		return false
	}
	if a.Failures == nil {
		a.Failures = map[int]int{}
	}
	a.Failures[index]++
	a.LastError = errStringLocal(err)
	a.LastChange = time.Now()
	failed := 0
	for i := 0; i < vkActivePoolSize; i++ {
		if a.Failures[i] > 0 {
			failed++
		}
	}
	exhausted := failed >= vkActivePoolSize
	if exhausted {
		a.State = "exhausted"
	} else {
		a.State = "degraded"
	}
	m.accounts[id] = a
	m.mu.Unlock()
	if exhausted {
		// Invalidate synchronously before another goroutine can attempt to
		// recover this account from a stale 4+8 JSON file.
		m.invalidatePool(id)
	}
	return exhausted
}

func (m *VKMultiAccountManager) allAccountsExhausted() bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	if len(m.accounts) < 2 {
		return false
	}
	for _, id := range []string{m.primary, m.backup} {
		a, ok := m.accounts[id]
		if !ok || a.State != "exhausted" {
			return false
		}
	}
	return true
}

func (m *VKMultiAccountManager) markHashHealthy(id string, index int) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if a, ok := m.accounts[id]; ok {
		if a.Failures == nil {
			a.Failures = map[int]int{}
		}
		delete(a.Failures, index)
		if len(a.Failures) == 0 {
			a.State = "healthy"
			a.LastError = ""
		}
		a.LastChange = time.Now()
		m.accounts[id] = a
	}
}

func (m *VKMultiAccountManager) markHealthy(id string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if a, ok := m.accounts[id]; ok {
		a.State = "healthy"
		a.LastError = ""
		a.LastChange = time.Now()
		m.accounts[id] = a
	}
}

func (m *VKMultiAccountManager) statusSnapshot() map[string]map[string]any {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := make(map[string]map[string]any, len(m.accounts))
	for id, a := range m.accounts {
		failed := 0
		for i := 0; i < vkActivePoolSize; i++ {
			if a.Failures[i] > 0 {
				failed++
			}
		}
		out[id] = map[string]any{
			"name": a.Name, "state": a.State, "failed_active": failed,
			"last_error": a.LastError, "last_change": a.LastChange.Format(time.RFC3339),
			"primary": id == m.primary, "backup": id == m.backup, "active": id == m.active,
		}
	}
	return out
}

func errStringLocal(err error) string {
	if err == nil {
		return ""
	}
	return err.Error()
}

func appendVKEvent(msg string) {
	path := "/opt/etc/qwdtt/events.log"
	_ = os.MkdirAll("/opt/etc/qwdtt", 0700)
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return
	}
	defer f.Close()
	line := fmt.Sprintf("%s %s", time.Now().Format(time.RFC3339), msg)
	_, _ = fmt.Fprintln(f, line)
	go notifyVKEvent(line)
	if st, err := f.Stat(); err == nil && st.Size() > 512*1024 {
		_ = os.Rename(path, path+".1")
	}
}

func (m *VKMultiAccountManager) accountsSnapshot(id string) VKRuntimeAccount {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.accounts[id]
}

func (m *VKMultiAccountManager) activeID() string { m.mu.Lock(); defer m.mu.Unlock(); return m.active }
func (m *VKMultiAccountManager) primaryID() string {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.primary
}
func (m *VKMultiAccountManager) backupID() string { m.mu.Lock(); defer m.mu.Unlock(); return m.backup }

func setVKAccessTokenForAccount(token string) { setVKAccessToken(token) }

func startVKMultiAccountSupervisor(ctx context.Context) {
	if !vkAccountsManager.enabled() {
		return
	}
	go func() {
		ticker := time.NewTicker(10 * time.Minute)
		defer ticker.Stop()
		for {
			if ctx.Err() != nil {
				return
			}
			active := vkAccountsManager.activeID()
			primary := vkAccountsManager.primaryID()
			backup := vkAccountsManager.backupID()
			if active != "" && active != primary {
				// switchTo validates persisted active hashes and rebuilds any missing
				// slots. If the primary was exhausted earlier, its pool file was
				// invalidated, so a successful return means a fresh 4+8 pool exists.
				if err := vkAccountsManager.switchTo(primary); err != nil {
					log.Printf("[VK-ACCOUNTS] Не удалось вернуться на основной аккаунт: %v", err)
				} else {
					log.Printf("[VK-ACCOUNTS] Основной аккаунт восстановлен — автоматический возврат выполнен")
					appendVKEvent(fmt.Sprintf("🟢 Основной VK аккаунт %s восстановлен; выполнен автоматический возврат", primary))
				}
			} else if active != "" {
				// Keep the current account healthy. A partial reserve is acceptable;
				// fail over only when the account cannot maintain all four active slots.
				a, _, err := vkAccountsManager.prepare(active, vkActivePoolSize, vkReserveTarget)
				if err != nil && len(a) < vkActivePoolSize {
					if backup != "" && backup != active {
						if serr := vkAccountsManager.switchToWithPartialPool(backup); serr == nil {
							appendVKEvent(fmt.Sprintf("🔄 Аккаунт %s не восстановился; выполнено переключение на %s", active, backup))
						}
					}
				}
			}
			select {
			case <-ticker.C:
			case <-ctx.Done():
				return
			}
		}
	}()
}

func tryInitialVKAccountSelection(ctx context.Context, cfg entwareConfig, tp *TurnParams) error {
	vkAccountsManager.configure(ctx, cfg, tp)
	if !vkAccountsManager.enabled() {
		return nil
	}
	primary := vkAccountsManager.primaryID()
	if active, reserve, err := vkAccountsManager.prepare(primary, vkActivePoolSize, vkReserveTarget); len(active) >= vkActivePoolSize {
		if applyErr := vkAccountsManager.applyPool(primary, active, reserve); applyErr != nil {
			return applyErr
		}
		if err != nil {
			appendVKEvent(fmt.Sprintf("🟡 Основной VK %s запущен с неполным резервом %d/%d; восстановление резерва продолжается", primary, len(reserve), vkReserveTarget))
		}
		startVKMultiAccountSupervisor(ctx)
		return nil
	} else {
		log.Printf("[VK-ACCOUNTS] Основной аккаунт недоступен: %v; пробую резервный", err)
		appendVKEvent(fmt.Sprintf("🟠 Основной VK аккаунт %s недоступен; пробую резервный", primary))
	}
	backup := vkAccountsManager.backupID()
	if backup == "" {
		return fmt.Errorf("основной VK аккаунт недоступен, резервный не задан")
	}
	active, reserve, err := vkAccountsManager.prepare(backup, vkActivePoolSize, vkReserveTarget)
	if len(active) < vkActivePoolSize {
		appendVKEvent(fmt.Sprintf("🔴 Основной и резервный VK аккаунты недоступны: %v", err))
		return fmt.Errorf("основной и резервный VK аккаунты недоступны: %w", err)
	}
	if err := vkAccountsManager.applyPool(backup, active, reserve); err != nil {
		return err
	}
	if err != nil {
		appendVKEvent(fmt.Sprintf("🟡 Резервный VK %s запущен с неполным резервом %d/%d; восстановление резерва продолжается", backup, len(reserve), vkReserveTarget))
	}
	startVKMultiAccountSupervisor(ctx)
	return nil
}
