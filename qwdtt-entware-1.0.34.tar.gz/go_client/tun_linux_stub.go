//go:build !linux

package main

import (
	"fmt"
	"os"
)

func openLinuxTUN(name string) (*os.File, string, error) {
	return nil, "", fmt.Errorf("native Entware TUN is Linux-only")
}
func configureLinuxTUN(iface, assignedIP string, mtu int, gatewayMode bool, markIface string) error {
	return fmt.Errorf("native Entware routing is Linux-only")
}
