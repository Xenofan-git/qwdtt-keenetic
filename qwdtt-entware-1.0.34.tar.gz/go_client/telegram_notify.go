package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type TelegramRecipientConfig struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	BotToken string `json:"bot_token"`
	ChatID   string `json:"chat_id"`
	Enabled  bool   `json:"enabled"`
}

type telegramEvent struct {
	ID        string   `json:"id"`
	CreatedAt string   `json:"created_at"`
	Text      string   `json:"text"`
	Severity  string   `json:"severity,omitempty"`
	Pending   []string `json:"pending"`
}

type telegramNotifier struct {
	mu         sync.Mutex
	recipients map[string]TelegramRecipientConfig
	queuePath  string
	maxQueue   int
	wake       chan struct{}
	started    bool
	httpClient *http.Client
}

var qwdttTelegram = &telegramNotifier{recipients: map[string]TelegramRecipientConfig{}, queuePath: "/opt/etc/qwdtt/telegram.queue.jsonl", maxQueue: 200, wake: make(chan struct{}, 1), httpClient: &http.Client{Timeout: 5 * time.Second}}

func telegramNewID() string {
	b := make([]byte, 8)
	if _, err := rand.Read(b); err != nil {
		return fmt.Sprintf("%d", time.Now().UnixNano())
	}
	return hex.EncodeToString(b)
}

func configureTelegramNotifier(cfg []TelegramRecipientConfig) {
	qwdttTelegram.mu.Lock()
	defer qwdttTelegram.mu.Unlock()
	qwdttTelegram.recipients = map[string]TelegramRecipientConfig{}
	for _, r := range cfg {
		r.ID = strings.TrimSpace(r.ID)
		r.BotToken = strings.TrimSpace(r.BotToken)
		r.ChatID = strings.TrimSpace(r.ChatID)
		if r.ID == "" || r.BotToken == "" || r.ChatID == "" || !r.Enabled {
			continue
		}
		qwdttTelegram.recipients[r.ID] = r
	}
	if !qwdttTelegram.started {
		qwdttTelegram.started = true
		go qwdttTelegram.worker()
	}
	select {
	case qwdttTelegram.wake <- struct{}{}:
	default:
	}
}

func (n *telegramNotifier) enqueue(text string) {
	text = strings.TrimSpace(text)
	if text == "" {
		return
	}
	n.mu.Lock()
	recipients := make([]string, 0, len(n.recipients))
	for id := range n.recipients {
		recipients = append(recipients, id)
	}
	if len(recipients) == 0 {
		n.mu.Unlock()
		return
	}
	severity := telegramSeverity(text)
	ev := telegramEvent{ID: telegramNewID(), CreatedAt: time.Now().Format(time.RFC3339), Text: text, Severity: severity, Pending: recipients}
	_ = n.appendEventLocked(ev)
	n.mu.Unlock()
	select {
	case n.wake <- struct{}{}:
	default:
	}
}

func (n *telegramNotifier) appendEventLocked(ev telegramEvent) error {
	if err := os.MkdirAll(filepath.Dir(n.queuePath), 0700); err != nil {
		return err
	}
	f, err := os.OpenFile(n.queuePath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	defer f.Close()
	b, _ := json.Marshal(ev)
	if _, err := f.Write(append(b, '\n')); err != nil {
		return err
	}
	return n.trimQueueLocked()
}

func (n *telegramNotifier) loadQueueLocked() []telegramEvent {
	f, err := os.Open(n.queuePath)
	if err != nil {
		return nil
	}
	defer f.Close()
	var out []telegramEvent
	s := bufio.NewScanner(f)
	s.Buffer(make([]byte, 4096), 256*1024)
	for s.Scan() {
		var e telegramEvent
		if json.Unmarshal(s.Bytes(), &e) == nil && e.ID != "" && len(e.Pending) > 0 {
			out = append(out, e)
		}
	}
	return out
}

func (n *telegramNotifier) writeQueueLocked(events []telegramEvent) error {
	tmp := n.queuePath + ".tmp"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	enc := json.NewEncoder(f)
	for _, e := range events {
		if err := enc.Encode(e); err != nil {
			f.Close()
			return err
		}
	}
	if err := f.Sync(); err != nil {
		f.Close()
		return err
	}
	if err := f.Close(); err != nil {
		return err
	}
	return os.Rename(tmp, n.queuePath)
}

func telegramSeverity(text string) string {
	lower := strings.ToLower(text)
	if strings.Contains(text, "🔴") || strings.Contains(lower, "critical") || strings.Contains(lower, "exhausted") || strings.Contains(lower, "both vk") {
		return "critical"
	}
	if strings.Contains(text, "🟠") || strings.Contains(text, "⚠️") || strings.Contains(text, "🔄") || strings.Contains(lower, "captcha") || strings.Contains(lower, "switch") {
		return "warning"
	}
	return "info"
}

func compactTelegramEvents(events []telegramEvent, max int) []telegramEvent {
	if len(events) <= max {
		return events
	}
	// Never drop CRITICAL events. Keep a bounded tail of warnings and info.
	crit := make([]telegramEvent, 0)
	warn := make([]telegramEvent, 0)
	info := make([]telegramEvent, 0)
	for _, e := range events {
		sev := e.Severity
		if sev == "" {
			sev = telegramSeverity(e.Text)
		}
		switch sev {
		case "critical":
			crit = append(crit, e)
		case "warning":
			warn = append(warn, e)
		default:
			info = append(info, e)
		}
	}
	if len(crit) >= max {
		return crit[len(crit)-max:]
	}
	budget := max - len(crit)
	if len(warn) > budget/2+budget%2 {
		warn = warn[len(warn)-(budget/2+budget%2):]
	}
	budget -= len(warn)
	if len(info) > budget {
		info = info[len(info)-budget:]
	}
	out := append(append(append([]telegramEvent{}, crit...), warn...), info...)
	// Preserve chronological order after category compaction.
	for i := 1; i < len(out); i++ {
		for j := i; j > 0 && out[j].CreatedAt < out[j-1].CreatedAt; j-- {
			out[j], out[j-1] = out[j-1], out[j]
		}
	}
	return out
}

func (n *telegramNotifier) trimQueueLocked() error {
	events := n.loadQueueLocked()
	if len(events) <= n.maxQueue {
		return nil
	}
	events = compactTelegramEvents(events, n.maxQueue)
	return n.writeQueueLocked(events)
}

func (n *telegramNotifier) send(r TelegramRecipientConfig, text string) error {
	endpoint := "https://api.telegram.org/bot" + r.BotToken + "/sendMessage"
	form := url.Values{}
	form.Set("chat_id", r.ChatID)
	form.Set("text", text)
	form.Set("disable_web_page_preview", "true")
	req, err := http.NewRequest(http.MethodPost, endpoint, strings.NewReader(form.Encode()))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	resp, err := n.httpClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("telegram HTTP %d", resp.StatusCode)
	}
	return nil
}

func (n *telegramNotifier) worker() {
	ticker := time.NewTicker(60 * time.Second)
	defer ticker.Stop()
	for {
		n.flush()
		select {
		case <-ticker.C:
		case <-n.wake:
		}
	}
}

func (n *telegramNotifier) flush() {
	n.mu.Lock()
	events := n.loadQueueLocked()
	recipients := make(map[string]TelegramRecipientConfig, len(n.recipients))
	for id, r := range n.recipients {
		recipients[id] = r
	}
	n.mu.Unlock()
	if len(events) == 0 || len(recipients) == 0 {
		return
	}

	// When Telegram has been unavailable for a long time, collapse a huge
	// backlog before delivery. Critical events are retained; routine noise is
	// bounded so a blocked Telegram API can never grow the queue without limit.
	if len(events) > 40 {
		events = compactTelegramEvents(events, 40)
		n.mu.Lock()
		_ = n.writeQueueLocked(events)
		n.mu.Unlock()
	}

	changed := false
	for i := range events {
		pending := events[i].Pending[:0]
		for _, id := range events[i].Pending {
			r, ok := recipients[id]
			if !ok {
				changed = true
				continue
			}
			if err := n.send(r, events[i].Text); err != nil {
				pending = append(pending, id)
				continue
			}
			changed = true
		}
		events[i].Pending = append([]string(nil), pending...)
	}
	kept := events[:0]
	for _, e := range events {
		if len(e.Pending) > 0 {
			kept = append(kept, e)
		}
	}
	if changed {
		n.mu.Lock()
		_ = n.writeQueueLocked(kept)
		n.mu.Unlock()
	}
}

func (n *telegramNotifier) testAll(ctx context.Context) map[string]string {
	n.mu.Lock()
	rs := make([]TelegramRecipientConfig, 0, len(n.recipients))
	for _, r := range n.recipients {
		rs = append(rs, r)
	}
	n.mu.Unlock()
	out := map[string]string{}
	for _, r := range rs {
		select {
		case <-ctx.Done():
			out[r.ID] = "cancelled"
			continue
		default:
		}
		if err := n.send(r, "🧪 qWDTT: тестовое уведомление Telegram\nКанал связи работает. qWDTT не зависит от Telegram."); err != nil {
			out[r.ID] = err.Error()
		} else {
			out[r.ID] = "ok"
		}
	}
	return out
}

func notifyVKEvent(msg string) { qwdttTelegram.enqueue("📡 qWDTT\n" + msg) }
