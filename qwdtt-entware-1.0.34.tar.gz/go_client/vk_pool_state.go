package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

type VKPoolState struct {
	Version          int      `json:"version"`
	TokenFingerprint string   `json:"token_fingerprint"`
	Active           []string `json:"active"`
	Reserve          []string `json:"reserve"`
}

var vkPoolStateMu sync.Mutex
var vkPoolStatePath string
var vkPoolTokenFingerprint string

func setVKPoolStatePath(path, token string) {
	vkPoolStatePath = strings.TrimSpace(path)
	vkPoolTokenFingerprint = tokenFingerprint(token)
}

func tokenFingerprint(token string) string {
	token = strings.TrimSpace(token)
	if token == "" {
		return ""
	}
	sum := sha256.Sum256([]byte(token))
	return hex.EncodeToString(sum[:])[:16]
}

func loadVKPoolState(path, token string) (VKPoolState, bool) {
	if strings.TrimSpace(path) == "" {
		return VKPoolState{}, false
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return VKPoolState{}, false
	}
	var s VKPoolState
	if json.Unmarshal(b, &s) != nil || s.Version != 1 {
		return VKPoolState{}, false
	}
	if s.TokenFingerprint != tokenFingerprint(token) {
		return VKPoolState{}, false
	}
	s.Active = uniqueHashes(s.Active)
	s.Reserve = uniqueHashes(s.Reserve)
	return s, len(s.Active)+len(s.Reserve) > 0
}

func saveVKPoolState(active, reserve []string) {
	saveVKPoolStateAt(vkPoolStatePath, "", active, reserve)
}

func saveVKPoolStateAt(path, token string, active, reserve []string) error {
	path = strings.TrimSpace(path)
	fp := vkPoolTokenFingerprint
	if strings.TrimSpace(token) != "" {
		fp = tokenFingerprint(token)
	}
	if path == "" || fp == "" {
		return fmt.Errorf("pool state path or token fingerprint is empty")
	}
	s := VKPoolState{Version: 1, TokenFingerprint: fp, Active: uniqueHashes(active), Reserve: uniqueHashes(reserve)}
	b, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return err
	}
	vkPoolStateMu.Lock()
	defer vkPoolStateMu.Unlock()
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, b, 0600); err != nil {
		return err
	}
	if err := os.Rename(tmp, path); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	return nil
}

func uniqueHashes(in []string) []string {
	out := make([]string, 0, len(in))
	seen := map[string]bool{}
	for _, h := range in {
		h = normalizeVKJoinHash(h)
		if h == "" || seen[h] {
			continue
		}
		seen[h] = true
		out = append(out, h)
	}
	return out
}

func poolSnapshot(tp *TurnParams) ([]string, []string) {
	tp.hashMu.RLock()
	active := append([]string(nil), tp.Hashes...)
	tp.hashMu.RUnlock()
	tp.reserveMu.Lock()
	reserve := append([]string(nil), tp.ReserveHashes...)
	tp.reserveMu.Unlock()
	return active, reserve
}

func persistVKPool(tp *TurnParams) {
	a, r := poolSnapshot(tp)
	if vkAccountsManager != nil && vkAccountsManager.enabled() {
		id := vkAccountsManager.activeID()
		if acc, ok := vkAccountsManager.account(id); ok {
			saveVKPoolStateAt(acc.PoolPath, acc.AccessToken, a, r)
			return
		}
	}
	saveVKPoolState(a, r)
}

func validatePoolState(s VKPoolState) error {
	if len(s.Active) > vkActivePoolSize {
		return fmt.Errorf("too many active hashes")
	}
	if len(s.Reserve) > vkReserveTarget {
		return fmt.Errorf("too many reserve hashes")
	}
	return nil
}
