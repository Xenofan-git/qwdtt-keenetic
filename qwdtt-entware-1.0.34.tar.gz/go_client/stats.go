package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"sync/atomic"
	"time"
)

type Stats struct {
	TotalBytesUp      atomic.Int64
	TotalBytesDown    atomic.Int64
	ActiveConnections atomic.Int32
	LastTrafficUnix   atomic.Int64
	LastSessionUnix   atomic.Int64
}

func NewStats() *Stats {
	s := &Stats{}
	s.LastTrafficUnix.Store(time.Now().Unix())
	s.LastSessionUnix.Store(time.Now().Unix())
	return s
}

func (s *Stats) RunLoop(shutdown <-chan struct{}) {
	ticker := time.NewTicker(3 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-shutdown:
			return
		case <-ticker.C:
			active := s.ActiveConnections.Load()
			up := s.TotalBytesUp.Load()
			down := s.TotalBytesDown.Load()
			totalMB := float64(up+down) / (1024.0 * 1024.0)
			upMB := float64(up) / (1024.0 * 1024.0)
			downMB := float64(down) / (1024.0 * 1024.0)

			log.Printf("[СТАТИСТИКА] Активных: %d | Трафик: %.2f МБ | ↓%.2f МБ / ↑%.2f МБ", active, totalMB, downMB, upMB)
		}
	}
}

func writeClientHealthHeartbeat(ctx context.Context, stats *Stats) {
	path := "/opt/etc/qwdtt/client-health.json"
	t := time.NewTicker(5 * time.Second)
	defer t.Stop()
	write := func() {
		_ = os.MkdirAll("/opt/etc/qwdtt", 0700)
		b := fmt.Sprintf(`{"updated_at":%d,"last_traffic":%d,"last_session":%d,"active_connections":%d,"rx_bytes":%d,"tx_bytes":%d}\n`, time.Now().Unix(), stats.LastTrafficUnix.Load(), stats.LastSessionUnix.Load(), stats.ActiveConnections.Load(), stats.TotalBytesDown.Load(), stats.TotalBytesUp.Load())
		tmp := path + ".tmp"
		if os.WriteFile(tmp, []byte(b), 0600) == nil {
			_ = os.Rename(tmp, path)
		}
	}
	write()
	for {
		select {
		case <-t.C:
			write()
		case <-ctx.Done():
			write()
			return
		}
	}
}
