package main

import (
	"context"
	"log"
	"math/rand"
	"net"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

const workersPerGroup = 9

// Entware automatic VK mode keeps four active hashes and eight reserve hashes.
// Reserve hashes are consumed on rotation so a CAPTCHA/rate-limit event does not
// immediately stop a worker.
const vkActivePoolSize = 4
const vkReserveTarget = 8
const vkPoolTarget = vkActivePoolSize + vkReserveTarget

var vkPoolRefillMu sync.Mutex

const allocateGateInterval = 100 * time.Millisecond

var vkHashRotationMu sync.Mutex

// WorkerGroup:
// Запускает 9 потоков с одними кредами. Ротации нет — работает до смерти воркеров.
func WorkerGroup(
	ctx context.Context,
	groupID int,
	hashIndex int,
	tp *TurnParams,
	peer *net.UDPAddr,
	d *Dispatcher,
	localPort string,
	getConfig bool,
	configCh chan<- string,
	workerIDs []int,
	pauseFlag *int32,
	deviceID, password string,
	stats *Stats,
	waitReady <-chan struct{},
	signalReady chan<- struct{},
) {
	// Каскадный запуск: ждем свою очередь
	if waitReady != nil {
		log.Printf("[ГРУППА #%d] Ожидание сигнала от предыдущей группы...", groupID)
		select {
		case <-waitReady:
		case <-ctx.Done():
			return
		}
	}

	var configSent int32
	if !getConfig {
		configSent = 1
	}

	// Doze-mode пауза
	for atomic.LoadInt32(pauseFlag) != 0 {
		if ctx.Err() != nil {
			return
		}
		time.Sleep(1 * time.Second)
	}

	hash := tp.getHash(hashIndex)
	shortHash := hash
	if len(shortHash) > 8 {
		shortHash = shortHash[:8]
	}
	log.Printf("[ГРУППА #%d] Запрос кредов (хеш: %s...)", groupID, shortHash)

	credStreamID := groupID * 100
	user, pass, turnURLs, err := getCredsAutoRotate(ctx, tp, hashIndex, hash, credStreamID, groupID)
	var creds *Credentials
	if err == nil {
		creds = &Credentials{User: user, Pass: pass, TurnURLs: turnURLs, CacheStreamID: credStreamID}
	} else {
		log.Printf("[ГРУППА #%d] Ошибка кредов: %v", groupID, err)
		return
	}

	log.Printf("[ГРУППА #%d] Креды OK, TURN: %v, %d воркеров", groupID, creds.TurnURLs, len(workerIDs))

	var configRequestInFlight int32
	var wg sync.WaitGroup
	var credsMu sync.RWMutex
	var refreshMu sync.Mutex
	var lastCredRefresh atomic.Int64

	refreshCreds := func(reason string) bool {
		refreshMu.Lock()
		defer refreshMu.Unlock()

		now := time.Now().Unix()
		last := lastCredRefresh.Load()
		if last > 0 && now-last < 15 {
			log.Printf("[TURN] Креды уже обновлялись %d сек назад, ждём следующий retry (%s)", now-last, reason)
			return true
		}

		getStreamCache(credStreamID).invalidate(credStreamID)
		if getVkAuthMode() == "account" {
			invalidateInjectedTurnCreds(hash)
		}
		u, p, urls, refreshErr := getCredsAutoRotate(ctx, tp, hashIndex, hash, credStreamID, groupID)
		if refreshErr != nil {
			log.Printf("[TURN] Не удалось обновить креды после %s: %v", reason, refreshErr)
			return false
		}

		credsMu.Lock()
		creds = &Credentials{User: u, Pass: p, TurnURLs: urls, CacheStreamID: credStreamID}
		credsMu.Unlock()
		lastCredRefresh.Store(time.Now().Unix())
		log.Printf("[TURN] Креды обновлены после %s, TURN urls=%d", reason, len(urls))
		return true
	}

	// Сигнализируем следующей группе, что мы успешно запустились (креды получены + фора)
	if signalReady != nil {
		go func() {
			delayMs := 500 + rand.Intn(250)
			time.Sleep(time.Duration(delayMs) * time.Millisecond)
			close(signalReady)
			log.Printf("[ГРУППА #%d] Успешный старт! Передача эстафеты следующей группе...", groupID)
		}()
	}

	// Общий rate-limit на TURN Allocate по всей группе: не более одной новой
	// аллокации за тик, независимо от того, сколько воркеров сейчас готовы
	// её выполнить (стартовый stagger — отдельная вещь, см. workerDelay ниже —
	// он размазывает старт горутин, но не сами ретраи Allocate внутри уже
	// запущенных). Без этого на нестабильной сети несколько воркеров всё
	// равно накладываются друг на друга и вместе выжигают VK-квоту (error
	// 486) быстрее, чем должны. См. RunSession(allocateGate) в session.go и
	// комментарий там про free-turn-proxy — тот же приём.
	allocateTicker := time.NewTicker(allocateGateInterval)
	defer allocateTicker.Stop()

	for i, wid := range workerIDs {
		wg.Add(1)

		workerDelay := time.Duration(i) * 75 * time.Millisecond

		go func(wid int, delay time.Duration) {
			defer wg.Done()

			if delay > 0 {
				select {
				case <-time.After(delay):
				case <-ctx.Done():
					return
				}
			}

			shouldGetConfig := getConfig
			attempt := 0

			for {
				if ctx.Err() != nil {
					return
				}

				getConf := false
				if shouldGetConfig && atomic.LoadInt32(&configSent) == 0 {
					getConf = atomic.CompareAndSwapInt32(&configRequestInFlight, 0, 1)
				}
				var cc chan<- string
				if getConf {
					cc = configCh
				}

				credsMu.RLock()
				credsSnapshot := *creds
				credsSnapshot.TurnURLs = cloneStringSlice(creds.TurnURLs)
				credsMu.RUnlock()

				configDelivered, sessErr := RunSession(ctx, tp, peer, d, localPort,
					getConf, cc, wid, &credsSnapshot, deviceID, password, stats, allocateTicker.C)

				quotaRetry := false
				fastRetry := false
				if getConf {
					if configDelivered {
						atomic.StoreInt32(&configSent, 1)
					} else {
						atomic.StoreInt32(&configRequestInFlight, 0)
					}
				}

				if sessErr != nil {
					if ctx.Err() != nil {
						return
					}
					errStr := sessErr.Error()
					errStrLower := strings.ToLower(errStr)
					fastRetry = strings.Contains(errStrLower, "broken pipe") ||
						strings.Contains(errStrLower, "connection reset by peer") ||
						strings.Contains(errStrLower, "unexpected eof")

					turnAllocAttrMissing := strings.Contains(errStrLower, "turn allocate") &&
						strings.Contains(errStrLower, "attribute not found")
					isTurnQuota := strings.Contains(errStrLower, "quota") || strings.Contains(errStr, "486")
					quotaRetry = isTurnQuota
					turnCredRefreshNeeded := !isTurnQuota && (turnAllocAttrMissing ||
						strings.Contains(errStrLower, "turn allocate auth") ||
						strings.Contains(errStrLower, "invalid credential") ||
						strings.Contains(errStrLower, "stale nonce") ||
						strings.Contains(errStrLower, "allocation mismatch") ||
						strings.Contains(errStrLower, "error 508"))

					if hint := workerErrorHint(sessErr); hint != "" {
						errStr += " | " + hint
					} else if strings.Contains(errStrLower, "rate limit") ||
						strings.Contains(errStrLower, "flood control") ||
						strings.Contains(errStrLower, "ip mismatch") ||
						strings.Contains(errStrLower, "error 29") {
						errStr += " (ошибка со стороны ВК)"
					}

					if strings.Contains(errStr, "хеш мёртв") || strings.Contains(errStr, "FATAL_AUTH") {
						if token := getVKAccessToken(); token != "" {
							newHash, genErr := generateVKCallHashGuarded(ctx, token)
							if genErr == nil {
								oldHash := tp.getHash(hashIndex)
								if newHash != oldHash {
									refreshMu.Lock()
									getStreamCache(credStreamID).invalidate(credStreamID)
									refreshMu.Unlock()
									tp.replaceHash(hashIndex, newHash)
									invalidateInjectedTurnCreds(oldHash)
									log.Printf("[ВОРКЕР #%d] VK hash автоматически заменён: %s... -> %s...", wid, shortHashForLog(oldHash), shortHashForLog(newHash))
									if refreshCreds("умер VK hash") {
										attempt = 0
										continue
									}
								}
							} else {
								log.Printf("[ВОРКЕР #%d] Не удалось создать новый VK hash: %v", wid, genErr)
							}
						}
						log.Printf("[ВОРКЕР #%d] Фатальная ошибка: %s", wid, errStr)
						return
					}

					attempt++
					if isTurnQuota {
						log.Printf("[ВОРКЕР #%d] [TURN] Квота relay исчерпана (один аккаунт VK = мало слотов), ждём: %s", wid, errStr)
					} else if turnAllocAttrMissing {
						log.Printf("[ВОРКЕР #%d] [TURN] Allocate вернул неполный ответ, обновляем TURN-креды и повторяем (попытка %d): %s", wid, attempt, errStr)
						refreshCreds("TURN Allocate attribute-not-found")
					} else if turnCredRefreshNeeded {
						log.Printf("[ВОРКЕР #%d] [TURN] Ошибка allocation/кредов, обновляем TURN-креды и повторяем (попытка %d): %s", wid, attempt, errStr)
						refreshCreds("TURN allocation error")
					} else {
						log.Printf("[ВОРКЕР #%d] Ошибка (попытка %d): %s", wid, attempt, errStr)
					}

					// Если ошибка STUN (credentials invalid), воркер не сможет переподключиться. Завершаем.
					isStunDeath := strings.Contains(errStrLower, "error 29") ||
						strings.Contains(errStrLower, "cannot create socket")

					if isStunDeath {
						log.Printf("[ВОРКЕР #%d] Невосстановимая TURN/STUN ошибка, завершение: %s", wid, errStr)
						return
					}
				}

				if ctx.Err() != nil {
					return
				}

				retryDelay := time.Duration(5+rand.Intn(11)) * time.Second
				if quotaRetry {
					retryDelay = time.Duration(30+rand.Intn(31)) * time.Second
				} else if fastRetry {
					retryDelay = time.Duration(1+rand.Intn(3)) * time.Second
				}
				select {
				case <-time.After(retryDelay):
				case <-ctx.Done():
					return
				}
			}
		}(wid, workerDelay)
	}

	wg.Wait()
	log.Printf("[ГРУППА #%d] Все воркеры группы завершились.", groupID)
}

// ParseHashes — парсит строку хешей
func ParseHashes(raw string) []string {
	var result []string
	seen := make(map[string]struct{})
	for _, h := range strings.FieldsFunc(raw, func(r rune) bool {
		return r == ',' || r == ';' || r == '\n' || r == '\r' || r == '\t' || r == ' '
	}) {
		h = normalizeVKJoinHash(h)
		if h != "" {
			if _, exists := seen[h]; exists {
				continue
			}
			seen[h] = struct{}{}
			result = append(result, h)
		}
	}
	return result
}

func normalizeVKJoinHash(input string) string {
	s := strings.Trim(strings.TrimSpace(input), "<>\"'")
	if s == "" {
		return ""
	}

	lower := strings.ToLower(s)
	if idx := strings.Index(lower, "/call/join/"); idx >= 0 {
		s = s[idx+len("/call/join/"):]
	} else if strings.HasPrefix(lower, "http://") || strings.HasPrefix(lower, "https://") {
		return ""
	}

	if idx := strings.IndexAny(s, "?#/"); idx != -1 {
		s = s[:idx]
	}
	return strings.Trim(strings.TrimSpace(s), "/")
}

// getHash returns the current hash assigned to a worker group.
func (tp *TurnParams) getHash(index int) string {
	tp.hashMu.RLock()
	defer tp.hashMu.RUnlock()
	if len(tp.Hashes) == 0 {
		return ""
	}
	return tp.Hashes[index%len(tp.Hashes)]
}

func (tp *TurnParams) replaceHash(index int, hash string) {
	tp.hashMu.Lock()
	if len(tp.Hashes) == 0 || strings.TrimSpace(hash) == "" {
		tp.hashMu.Unlock()
		return
	}
	tp.Hashes[index%len(tp.Hashes)] = strings.TrimSpace(hash)
	tp.hashMu.Unlock()
	persistVKPool(tp)
}

// popReserveHash atomically takes one pre-created hash from the reserve pool.
func (tp *TurnParams) popReserveHash() string {
	tp.reserveMu.Lock()
	if len(tp.ReserveHashes) == 0 {
		tp.reserveMu.Unlock()
		return ""
	}
	h := tp.ReserveHashes[0]
	tp.ReserveHashes = tp.ReserveHashes[1:]
	tp.reserveMu.Unlock()
	persistVKPool(tp)
	return h
}

func (tp *TurnParams) activeCount() int {
	tp.hashMu.RLock()
	defer tp.hashMu.RUnlock()
	return len(tp.Hashes)
}

func (tp *TurnParams) reserveCount() int {
	tp.reserveMu.Lock()
	defer tp.reserveMu.Unlock()
	return len(tp.ReserveHashes)
}

func (tp *TurnParams) requeueReserveHash(hash string) bool {
	hash = strings.TrimSpace(hash)
	if hash == "" {
		return false
	}
	tp.reserveMu.Lock()
	defer tp.reserveMu.Unlock()
	for _, h := range tp.ReserveHashes {
		if h == hash {
			return false
		}
	}
	// Put a temporarily uncheckable hash back at the end of the reserve
	// queue. Network/CAPTCHA/rate-limit errors must not consume a good reserve
	// entry permanently.
	tp.ReserveHashes = append(tp.ReserveHashes, hash)
	persistVKPool(tp)
	return true
}

func (tp *TurnParams) addReserveHash(hash string) bool {
	hash = strings.TrimSpace(hash)
	if hash == "" {
		return false
	}
	tp.reserveMu.Lock()
	for _, h := range tp.ReserveHashes {
		if h == hash {
			tp.reserveMu.Unlock()
			return false
		}
	}
	tp.ReserveHashes = append(tp.ReserveHashes, hash)
	tp.reserveMu.Unlock()
	persistVKPool(tp)
	return true
}

// getCredsAutoRotate retries a dead VK call by creating a new call through
// VK calls.start when an access token is configured.
func getCredsAutoRotate(ctx context.Context, tp *TurnParams, hashIndex int, hash string, streamID, groupID int) (string, string, []string, error) {
	user, pass, urls, err := GetCreds(ctx, hash, streamID)
	if err == nil {
		if id := vkAccountsManager.activeID(); id != "" && vkAccountsManager.enabled() {
			vkAccountsManager.markHashHealthy(id, hashIndex)
		}
		return user, pass, urls, nil
	}
	if _, ok := asCallUnavailableError(err); !ok {
		return "", "", nil, err
	}
	token := getVKAccessToken()
	if token == "" {
		log.Printf("[ГРУППА #%d] VK hash недействителен, но VK access token не задан — автоматическая замена невозможна", groupID)
		return "", "", nil, err
	}
	log.Printf("[ГРУППА #%d] VK hash недействителен — создаю новый звонок через VK calls.start", groupID)
	// Only one worker/group may rotate a given hash at a time. If another
	// worker already replaced it while we waited, reuse the new hash instead
	// of creating another VK call and consuming another quota slot.
	vkHashRotationMu.Lock()
	current := tp.getHash(hashIndex)
	if current != hash && current != "" {
		vkHashRotationMu.Unlock()
		return GetCreds(ctx, current, streamID)
	}
	var newHash string
	var genErr error
	// Prefer a reserve hash, but validate it before assigning it. A stale reserve
	// entry must never kill the worker; discard it and try the next one.
	for {
		candidate := tp.popReserveHash()
		if candidate == "" {
			break
		}
		if candidate == hash || candidate == current {
			continue
		}
		cu, cp, cuurls, cerr := GetCreds(ctx, candidate, streamID)
		if cerr == nil {
			newHash = candidate
			tp.replaceHash(hashIndex, newHash)
			vkHashRotationMu.Unlock()
			if id := vkAccountsManager.activeID(); id != "" && vkAccountsManager.enabled() {
				vkAccountsManager.markHashHealthy(id, hashIndex)
			}
			log.Printf("[ГРУППА #%d] VK hash обновлён из резерва: %s... -> %s...", groupID, shortHashForLog(hash), shortHashForLog(newHash))
			appendVKEvent(fmt.Sprintf("⚠️ VK hash заменён из резерва: worker #%d; active=%d reserve=%d", groupID, tp.activeCount(), tp.reserveCount()))
			invalidateInjectedTurnCreds(hash)
			if token != "" && tp.reserveCount() < vkReserveTarget {
				go refillVKReserve(ctx, tp, token)
			}
			return cu, cp, cuurls, nil
		}
		status, _ := classifyHashCheckError(cerr)
		if status == "captcha" || status == "limited" || status == "network" {
			tp.requeueReserveHash(candidate)
			log.Printf("[VK-POOL] Резервный hash %s... временно недоступен (%s), возвращаю в резерв: %v", shortHashForLog(candidate), status, cerr)
			break
		}
		log.Printf("[VK-POOL] Резервный hash %s... недействителен, выбрасываю: %v", shortHashForLog(candidate), cerr)
	}
	for attempt := 1; attempt <= 3; attempt++ {
		newHash, genErr = generateVKCallHashGuarded(ctx, token)
		if genErr == nil {
			break
		}
		if attempt < 3 {
			select {
			case <-time.After(time.Duration(attempt) * time.Second):
			case <-ctx.Done():
				vkHashRotationMu.Unlock()
				return "", "", nil, ctx.Err()
			}
		}
	}
	if genErr != nil {
		currentAccount := vkAccountsManager.activeID()
		shouldFailover := false
		if vkAccountsManager.enabled() && currentAccount != "" {
			shouldFailover = vkAccountsManager.noteHashFailure(currentAccount, hashIndex, genErr)
		}
		vkHashRotationMu.Unlock()
		// A single dead hash must never switch the whole VK account. The
		// reserve pool handles isolated failures. Fail over only after all four
		// active slots have failed and the account cannot replenish them.
		if shouldFailover {
			appendVKEvent(fmt.Sprintf("VK account %s exhausted; switching to backup", currentAccount))
			fallback := vkAccountsManager.backupID()
			if currentAccount == fallback {
				fallback = vkAccountsManager.primaryID()
			}
			if fallback != "" && fallback != currentAccount {
				if switchErr := vkAccountsManager.switchTo(fallback); switchErr == nil {
					newCurrent := tp.getHash(hashIndex)
					if newCurrent != "" {
						log.Printf("[VK-ACCOUNTS] Аккаунт %s исчерпан; worker #%d продолжает через %s", currentAccount, groupID, fallback)
						return GetCreds(ctx, newCurrent, streamID)
					}
				}
			}
			// HydraRoute failover is owned by the web health watchdog. It waits
			// for persistent loss instead of reacting immediately to a VK event.
		}
		return "", "", nil, fmt.Errorf("VK hash rotation: %w (old: %v)", genErr, err)
	}
	tp.replaceHash(hashIndex, newHash)
	vkHashRotationMu.Unlock()
	log.Printf("[ГРУППА #%d] VK hash обновлён: %s... -> %s...", groupID, shortHashForLog(hash), shortHashForLog(newHash))
	appendVKEvent(fmt.Sprintf("⚠️ VK hash пересоздан: worker #%d; active=%d reserve=%d", groupID, tp.activeCount(), tp.reserveCount()))
	invalidateInjectedTurnCreds(hash)
	if token != "" && tp.reserveCount() < vkReserveTarget {
		go refillVKReserve(ctx, tp, token)
	}
	return GetCreds(ctx, newHash, streamID)
}

func refillVKReserve(ctx context.Context, tp *TurnParams, token string) {
	if token == "" || tp.reserveCount() >= vkReserveTarget {
		return
	}
	if !vkPoolRefillMu.TryLock() {
		return
	}
	defer vkPoolRefillMu.Unlock()
	for tp.reserveCount() < vkReserveTarget {
		genCtx, cancel := context.WithTimeout(ctx, 25*time.Second)
		h, err := generateVKCallHashGuarded(genCtx, token)
		cancel()
		if err != nil {
			log.Printf("[VK-POOL] Резерв не пополнен (%d/%d): %v; активные worker'ы продолжают работу", tp.reserveCount(), vkReserveTarget, err)
			return
		}
		if !tp.addReserveHash(h) {
			return
		}
		log.Printf("[VK-POOL] Резерв пополнен: %d/%d", tp.reserveCount(), vkReserveTarget)
		select {
		case <-time.After(2 * time.Second):
		case <-ctx.Done():
			return
		}
	}
}

func startVKPoolRefillSupervisor(ctx context.Context, tp *TurnParams, token string) {
	if token == "" {
		return
	}
	go func() {
		// Retry periodically so a CAPTCHA solved later from the web panel can
		// replenish the reserve without restarting the tunnel.
		ticker := time.NewTicker(10 * time.Minute)
		defer ticker.Stop()
		for {
			if tp.reserveCount() < vkReserveTarget {
				refillVKReserve(ctx, tp, token)
			}
			select {
			case <-ticker.C:
			case <-ctx.Done():
				return
			}
		}
	}()
}

func shortHashForLog(s string) string {
	s = strings.TrimSpace(s)
	if len(s) > 8 {
		return s[:8]
	}
	return s
}

// TurnParams — конфигурация TURN
type TurnParams struct {
	Host          string
	Port          string
	Hashes        []string
	ReserveHashes []string
	hashMu        sync.RWMutex
	reserveMu     sync.Mutex
	PoolStatePath string
	WrapKey       []byte // Password-derived WRAP key (32 bytes), nil = disabled
	ObfsMode      string // "audio" or "video" — RTP masking mode
	// NoDTLS: пропустить DTLS и идти RTP-obfs AEAD напрямую поверх TURN relay.
	// Требует сервер, который умеет принимать прямые (без DTLS) сессии на
	// отдельном порту/слушателе — см. server/main.go -listen-direct.
	NoDTLS bool
	// RawMode: raw-IP без WireGuard (см. server/main.go -listen-raw, handleConnRaw).
	// Подразумевает NoDTLS — сервер на -listen-raw DTLS не понимает.
	RawMode bool
	// TCPTransport: соединяться с TURN-relay по TCP вместо UDP (см.
	// dialTURNConn в session.go). На некоторых сетях (замечено на
	// Ростелекоме) UDP до TURN душится/дропается провайдером агрессивнее,
	// чем TCP на тот же relay — этот флаг обходит именно это.
	TCPTransport bool
}

// Credentials — учетные данные TURN
type Credentials struct {
	User          string
	Pass          string
	TurnURLs      []string
	CacheStreamID int
}
