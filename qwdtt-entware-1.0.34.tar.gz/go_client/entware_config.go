package main

import (
	"encoding/json"
	"fmt"
	"os"
)

type VKAccountConfig struct {
	ID          string `json:"id"`
	Name        string `json:"name"`
	AccessToken string `json:"access_token"`
}

type entwareConfig struct {
	Mode                 string                    `json:"mode"`
	TunName              string                    `json:"tun_name"`
	GatewayMode          bool                      `json:"gateway_mode"`
	MarkIface            string                    `json:"mark_iface"`
	Workers              int                       `json:"workers"`
	TurnTCP              bool                      `json:"turn_tcp"`
	Obfs                 string                    `json:"obfs"`
	VKAuth               string                    `json:"vk_auth"`
	VKHashes             string                    `json:"vk_hashes"`
	VKAccessToken        string                    `json:"vk_access_token"`
	VKPoolState          string                    `json:"vk_pool_state"`
	VKPrimaryID          string                    `json:"vk_primary_id"`
	VKBackupID           string                    `json:"vk_backup_id"`
	VKAccounts           []VKAccountConfig         `json:"vk_accounts"`
	Telegram             []TelegramRecipientConfig `json:"telegram"`
	Peer                 string                    `json:"peer"`
	Password             string                    `json:"password"`
	Socks                string                    `json:"socks"`
	SocksAuth            bool                      `json:"socks_auth"`
	SocksUser            string                    `json:"socks_user"`
	SocksPass            string                    `json:"socks_pass"`
	VKCredsFile          string                    `json:"vk_creds_file"`
	DNS                  string                    `json:"go_dns"`
	HydraFailoverEnabled bool                      `json:"hydra_failover_enabled"`
	HydraProxyName       string                    `json:"hydra_proxy_name"`
	HydraPolicy          string                    `json:"hydra_policy"`
}

func loadEntwareConfig(path string) (entwareConfig, error) {
	var c entwareConfig
	if path == "" {
		return c, nil
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return c, fmt.Errorf("read config: %w", err)
	}
	if err := json.Unmarshal(b, &c); err != nil {
		return c, fmt.Errorf("parse config: %w", err)
	}
	return c, nil
}
