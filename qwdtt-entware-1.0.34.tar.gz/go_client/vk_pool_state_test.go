package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestVKPoolStateRoundTrip(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "pool.json")
	setVKPoolStatePath(path, "token-a")
	saveVKPoolState([]string{"a", "b", "a"}, []string{"c", "d", "c"})
	got, ok := loadVKPoolState(path, "token-a")
	if !ok || len(got.Active) != 2 || len(got.Reserve) != 2 {
		t.Fatalf("bad state: %#v %v", got, ok)
	}
	if _, ok := loadVKPoolState(path, "token-b"); ok {
		t.Fatal("state must not load for another token")
	}
}

func TestVKPoolStateAtomicFile(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "nested", "pool.json")
	setVKPoolStatePath(path, "token")
	saveVKPoolState([]string{"a"}, nil)
	if _, err := os.Stat(path); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(path + ".tmp"); !os.IsNotExist(err) {
		t.Fatalf("temporary file left behind: %v", err)
	}
}

func TestTurnParamsReserveOperations(t *testing.T) {
	setVKPoolStatePath("", "")
	tp := &TurnParams{Hashes: []string{"a"}, ReserveHashes: []string{"b", "c"}}
	if got := tp.popReserveHash(); got != "b" {
		t.Fatal(got)
	}
	if !tp.addReserveHash("d") {
		t.Fatal("expected add")
	}
	if tp.addReserveHash("c") {
		t.Fatal("duplicate accepted")
	}
	tp.replaceHash(0, "z")
	if tp.getHash(0) != "z" {
		t.Fatal(tp.getHash(0))
	}
}
