package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"
)

const (
	vkCallHashClientID   = "6287487"
	vkCallHashAPIVersion = "5.199"
)

// VK hash generation is deliberately rate-limited. CAPTCHA/rate-limit responses
// are treated as a temporary gate, not as a dead account/hash. This prevents
// qWDTT from hammering calls.start during a VK challenge.
type vkHashGenerationGate struct {
	mu    sync.Mutex
	next  map[string]time.Time
	fails map[string]int
}

var vkHashGenGate = vkHashGenerationGate{
	next:  make(map[string]time.Time),
	fails: make(map[string]int),
}

var vkHashGenerationSerial sync.Mutex

func vkHashTokenKey(token string) string {
	return tokenFingerprint(token)
}

func vkHashGenerationWait(ctx context.Context, token string) error {
	key := vkHashTokenKey(token)
	if key == "" {
		return nil
	}
	vkHashGenGate.mu.Lock()
	next := vkHashGenGate.next[key]
	vkHashGenGate.mu.Unlock()
	if next.IsZero() || !time.Now().Before(next) {
		return nil
	}
	d := time.Until(next)
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-t.C:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

func vkHashGenerationResult(token string, err error) {
	key := vkHashTokenKey(token)
	if key == "" {
		return
	}
	vkHashGenGate.mu.Lock()
	defer vkHashGenGate.mu.Unlock()
	if err == nil {
		delete(vkHashGenGate.fails, key)
		delete(vkHashGenGate.next, key)
		return
	}
	text := strings.ToLower(err.Error())
	if !strings.Contains(text, "captcha") && !strings.Contains(text, "rate limit") && !strings.Contains(text, "flood") && !strings.Contains(text, "error 29") && !strings.Contains(text, "error_code:29") {
		return
	}
	fails := vkHashGenGate.fails[key] + 1
	vkHashGenGate.fails[key] = fails
	delays := []time.Duration{time.Minute, 2 * time.Minute, 5 * time.Minute, 10 * time.Minute, 30 * time.Minute}
	idx := fails - 1
	if idx >= len(delays) {
		idx = len(delays) - 1
	}
	vkHashGenGate.next[key] = time.Now().Add(delays[idx])
	log.Printf("[VK-POOL] calls.start временно заблокирован (%s), следующая попытка через %s",
		map[bool]string{true: "CAPTCHA", false: "rate-limit"}[strings.Contains(text, "captcha")], delays[idx].Round(time.Second))
}

func generateVKCallHashGuarded(ctx context.Context, accessToken string) (string, error) {
	// Serialize calls.start globally. Several workers may discover a dead hash
	// at the same time; they must not turn that into a burst of VK call creation.
	vkHashGenerationSerial.Lock()
	defer vkHashGenerationSerial.Unlock()
	if err := vkHashGenerationWait(ctx, accessToken); err != nil {
		return "", err
	}
	h, err := generateVKCallHash(ctx, accessToken)
	vkHashGenerationResult(accessToken, err)
	return h, err
}

// generateVKCallHash creates a fresh VK call and returns the hash from join_link.
// The access token is obtained from the Android VK session in upstream qWDTT;
// Entware cannot host that WebView, so the token is supplied explicitly.
func generateVKCallHash(ctx context.Context, accessToken string) (string, error) {
	accessToken = strings.TrimSpace(accessToken)
	if accessToken == "" {
		return "", fmt.Errorf("VK access token is empty")
	}

	q := url.Values{}
	q.Set("access_token", accessToken)
	q.Set("v", vkCallHashAPIVersion)
	q.Set("client_id", vkCallHashClientID)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, "https://api.vk.ru/method/calls.start?"+q.Encode(), nil)
	if err != nil {
		return "", fmt.Errorf("create calls.start request: %w", err)
	}
	req.Header.Set("Accept", "application/json")
	req.Header.Set("User-Agent", "qWDTT-Entware/1.0")

	client := &http.Client{Timeout: 20 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return "", fmt.Errorf("calls.start request: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil {
		return "", fmt.Errorf("read calls.start response: %w", err)
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "", fmt.Errorf("calls.start HTTP %d: %s", resp.StatusCode, strings.TrimSpace(string(body)))
	}

	var result struct {
		Response struct {
			JoinLink string `json:"join_link"`
		} `json:"response"`
		Error *struct {
			Code int    `json:"error_code"`
			Msg  string `json:"error_msg"`
		} `json:"error,omitempty"`
	}
	if err := json.Unmarshal(body, &result); err != nil {
		return "", fmt.Errorf("decode calls.start response: %w", err)
	}
	if result.Error != nil {
		return "", fmt.Errorf("VK calls.start error %d: %s", result.Error.Code, result.Error.Msg)
	}
	join := strings.TrimSpace(result.Response.JoinLink)
	if join == "" {
		return "", fmt.Errorf("VK calls.start returned empty join_link")
	}

	// Accept both a full VK call URL and the bare hash.
	if i := strings.Index(join, "/call/join/"); i >= 0 {
		join = join[i+len("/call/join/"):]
	}
	join = strings.Trim(join, "/")
	if i := strings.IndexAny(join, "?#"); i >= 0 {
		join = join[:i]
	}
	if len(join) < 16 {
		return "", fmt.Errorf("VK returned invalid call hash")
	}
	return join, nil
}
