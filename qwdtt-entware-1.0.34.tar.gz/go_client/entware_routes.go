//go:build linux

package main

import (
	"fmt"
	"net"
	"os/exec"
	"strings"
)

const qwdttRouteTable = "51820"

func runIP(args ...string) error {
	out, err := exec.Command("ip", args...).CombinedOutput()
	if err != nil {
		return fmt.Errorf("ip %s: %v: %s", strings.Join(args, " "), err, strings.TrimSpace(string(out)))
	}
	return nil
}

func configureLinuxTUN(iface, assignedIP string, mtu int, gatewayMode bool, markIface string) error {
	ip := net.ParseIP(assignedIP)
	if ip == nil || ip.To4() == nil {
		return fmt.Errorf("bad raw IP %q", assignedIP)
	}
	if mtu <= 0 {
		mtu = 1300
	}
	_ = runIP("addr", "flush", "dev", iface)
	if err := runIP("addr", "add", assignedIP+"/16", "dev", iface); err != nil {
		return err
	}
	if err := runIP("link", "set", "mtu", fmt.Sprint(mtu), "dev", iface); err != nil {
		return err
	}
	if err := runIP("link", "set", iface, "up"); err != nil {
		return err
	}

	if !gatewayMode {
		return nil
	}
	// Policy routing keeps qWDTT's own outer TURN traffic on the normal
	// Keenetic route while forwarded LAN packets are sent to the TUN.
	_ = runIP("rule", "del", "fwmark", "1", "table", qwdttRouteTable)
	_ = runIP("route", "flush", "table", qwdttRouteTable)
	if err := runIP("route", "add", "default", "dev", iface, "table", qwdttRouteTable); err != nil {
		return err
	}
	if err := runIP("rule", "add", "pref", "10010", "fwmark", "1", "table", qwdttRouteTable); err != nil {
		return err
	}
	if markIface != "" {
		if err := installMarkRule(markIface); err != nil {
			return err
		}
	}
	return nil
}

func installMarkRule(iface string) error {
	// Replace the rule idempotently. We deliberately use the mangle table only
	// for forwarded ingress traffic, so qWDTT/VK/TURN sockets are not marked.
	_ = exec.Command("iptables", "-t", "mangle", "-D", "PREROUTING", "-i", iface, "-m", "mark", "--mark", "0x0/0x1", "-j", "MARK", "--set-mark", "1").Run()
	out, err := exec.Command("iptables", "-t", "mangle", "-I", "PREROUTING", "1", "-i", iface, "-m", "mark", "--mark", "0x0/0x1", "-j", "MARK", "--set-mark", "1").CombinedOutput()
	if err != nil {
		return fmt.Errorf("iptables mark: %v: %s", err, strings.TrimSpace(string(out)))
	}
	return nil
}
