# qWDTT Entware 1.0.27

## Native Keenetic SOCKS5 integration
- During installation, qWDTT automatically creates a native Keenetic `ProxyN` interface under `Internet -> Other connections -> Proxy connections` when `ndmc` is available.
- The proxy points to `192.168.1.1:1301` by default (or the active SOCKS profile port), uses SOCKS5, no authentication, and TCP only.
- An existing free `ProxyN` is selected automatically; the chosen interface is persisted in `/opt/etc/qwdtt/keenetic-proxy.conf` and reused on reboot.
- Profile save/start synchronizes the Keenetic proxy to the current SOCKS port.
- The proxy is intentionally **not** marked `ip global`, because qWDTT itself must reach its remote server through the physical WAN; making the local SOCKS proxy a default WAN would create a routing loop. The created connection can be selected in Keenetic access policies.
- qWDTT never changes existing Keenetic policies or unrelated Proxy interfaces.
- UDP SOCKS mode is explicitly disabled because the qWDTT local SOCKS listener is TCP-only.

# qWDTT Entware 1.0.26

This release adds WAN-aware tunnel recovery, an end-to-end SOCKS5 connectivity probe, a local client heartbeat for non-SOCKS modes, and bounded Telegram notification queue compaction. Telegram remains strictly optional and independent of qWDTT transport/recovery.

# qWDTT Entware 1.0.24

This stage moves the control plane closer to the Android app while keeping Entware/Linux semantics.

## Server management
- Multi-server persistent store.
- Real SSH deployment using the bundled `deploy.sh` and staged `wdtt-server`.
- Uploads admin token and generated owner password before invoking the installer.
- Correctly passes all deployment environment variables, including `WDTT_ADMIN_PORT`, `WDTT_DIRECT_PORT`, and `WDTT_RAW_PORT`.
- Captures `WDTT_ADMIN_PIN` from the installer output.
- Real remote uninstall endpoint.
- Remote health/status endpoint.
- Server list API redacts SSH passwords, private keys, bot tokens and admin tokens.

## Important
The source archive still does not contain a prebuilt `wdtt-server` asset. The deployment button will refuse to run until `entware/deploy/wdtt-server` is supplied by the build pipeline for the target Linux architecture.

Web panel default: `http://<router-lan-ip>:18080`.


## 0.9.0 — runtime control

The web backend now has a real local client process controller:
- `/api/tunnel/status` — qWDTT process state;
- `/api/tunnel/start` — starts the selected profile using its server, profile password, hashes and worker count;
- `/api/tunnel/stop` — sends SIGTERM;
- `/api/tunnel/restart` — stop operation for deterministic restart from UI;
- `/api/server/admin-health` — checks the installed server Admin API over HTTPS and can pin the deployed TLS fingerprint.

The profile model now stores the fields required by the original Android profile format: password, listen port and global-hash flag.

Set `QWDTT_CLIENT_BIN` if the client binary is not `/opt/bin/qwdtt`. The runtime profile is written with mode 0600 to `/opt/etc/qwdtt/runtime-profile.json`.

Important: the qWDTT client binary must be cross-compiled for the target Entware architecture before starting a profile. This source package does not contain a fabricated binary.

## Серверный бинарник

Для нового отдельного qWDTT-сервера используйте `scripts/build-server.sh`. Он собирает `wdtt-server` под Linux amd64 и arm64. Наш деплой по умолчанию использует DTLS 56100 и внутренний WG 56101, чтобы не конфликтовать с существующим Android-сервером на 56000/56001.


## Web UI
The mobile-first Web UI is based on the qWDTT Android screens supplied for this port. See `docs/WEB-UI.md`.


Порты VPS: 56100/UDP (DTLS/WRAP) и 56100/TCP (HTTP API), 56101/UDP (внутренний WireGuard), 56102/TCP (admin API).

### Автопересоздание VK hash

Entware-клиент может автоматически создать первый VK call, если хеши не заданы, а в профиле есть VK access token. Если уже используемый VK call hash умирает, клиент автоматически вызывает `calls.start`, получает новый `join_link`, заменяет hash только у соответствующей группы worker-ов и повторно получает TURN credentials. При ошибке недействительного call/join link клиент создаёт новый VK call, извлекает `join_link`, заменяет hash только у соответствующей группы worker-ов и повторно получает TURN credentials. TURN credentials при этом по-прежнему обновляются отдельно.

VK OAuth: веб-панель поддерживает вход через VK и получает access token через OAuth implicit flow. Для этого VK-приложение должно разрешать redirect URI `http://192.168.1.1:18080/vk/callback`; client ID задаётся `QWDTT_VK_CLIENT_ID` (по умолчанию `6287487`), redirect — `QWDTT_VK_REDIRECT_URI`. После входа токен сохраняется в профиле с правами 0600 и наружу веб-API не возвращается — показывается только `vk_access_token_set`. Если OAuth не настроен, токен можно по-прежнему ввести вручную.

## VK account auto-login

The Entware web UI can obtain the VK access token through the same legacy VK OAuth token flow used by the upstream Android qWDTT call-hash generator. The router never needs the VK password: the user logs in on VK's page, and the callback page posts the returned token to the local qWDTT API. The token is stored with the profile with restrictive file permissions.

Configure a VK OAuth application and set:

```sh
cp /opt/etc/qwdtt/vk.env.example /opt/etc/qwdtt/vk.env
vi /opt/etc/qwdtt/vk.env
```

Set `QWDTT_VK_CLIENT_ID` and an exact `QWDTT_VK_REDIRECT_URI`, for example `http://192.168.1.1:18080/vk/callback`. The redirect URI must be trusted by the VK application; do not use the upstream `6287487` client ID with a different redirect URI unless VK explicitly allows it.


## VK hash pool (1.0.21)

При наличии VK access token Entware-клиент поддерживает пул из 4 активных VK hash и до 8 резервных. При смерти активного hash сначала берётся резервный, поэтому остальные worker'ы не останавливаются. Пополнение резерва выполняется асинхронно и не блокирует рабочий туннель; если VK требует CAPTCHA или временно ограничивает создание звонков, активные соединения продолжают работу.


## 24/7 VK pool
Automatic VK mode persists a pool at `/opt/etc/qwdtt/vk-pool.json`: up to 4 active hashes plus up to 8 reserve hashes. The pool is keyed by a SHA-256 fingerprint of the VK access token, so changing accounts does not reuse the previous pool. Reserve hashes are validated before activation; invalid entries are discarded. Pool refill runs asynchronously and CAPTCHA/rate limits do not terminate already-running workers.

CAPTCHA is manual only. qWDTT never attempts to bypass it. If VK requires a check, the affected worker waits while other workers continue.

The web panel is protected by HTTP Basic Auth. Installation creates `/opt/etc/qwdtt/web.auth` with user `admin` and a random password and prints it once during installation.

## Два VK-аккаунта: основной + резервный

qWDTT Entware поддерживает два независимых VK-аккаунта в автоматическом режиме:

- каждый аккаунт имеет собственный постоянный пул `4 active + 8 reserve`;
- вручную выбирается, какой аккаунт считать основным, а какой резервным;
- при исчерпании пула/невозможности создать новый hash текущий аккаунт переключается на второй;
- основной аккаунт не отключается навсегда: supervisor каждые 10 минут проверяет, восстановился ли его полный пул;
- после восстановления полного пула `4 + 8` система автоматически возвращается на основной аккаунт;
- если VK требует CAPTCHA, автоматического обхода CAPTCHA нет — после ручного решения система продолжит попытки восстановления и вернётся на основной аккаунт, когда пул снова станет полным.

Пулы сохраняются отдельно:

- `/opt/etc/qwdtt/vk-pool.json.1`
- `/opt/etc/qwdtt/vk-pool.json.2`

Токены и состояние хранятся с правами `0600`.

## 1.0.22 stability/recovery

- Two VK accounts remain primary/backup; account failover occurs only after all four active slots of the current account have failed and cannot be replenished.
- A single dead hash never causes a whole-account switch; reserve hashes are tried first.
- Main-account recovery is tested periodically and the client automatically returns to the configured primary after a complete 4+8 pool is rebuilt.
- qWDTT web control plane now automatically restarts a tunnel process that exits unexpectedly.
- A local tunnel health watchdog checks the SOCKS listener or `qwdtt0` interface and restarts the tunnel only after three consecutive failed checks.
- Control-plane config keeps a `.bak` copy and all-important recovery events are recorded in `/opt/etc/qwdtt/events.log` (with a 512 KiB rollover).
- Telegram is intentionally not required for alerts/operation because Telegram access from Russia is currently blocked on many networks. The router remains fully functional without Telegram.

## Telegram notifications

Telegram is an optional notification channel only. qWDTT operation, VK pool failover, CAPTCHA handling, watchdogs and tunnel recovery do not depend on Telegram availability. Multiple Telegram bot recipients may be configured; enabled recipients receive the same events. Events are queued locally when Telegram is unreachable and retried later.


## 1.0.24 verification fixes
- Health watchdog restarts the tunnel after a failed health check; it no longer marks the watchdog restart as a manual stop.
- Profile saves preserve existing VK account tokens/names and primary/backup selection when the UI submits a partial/redacted profile.
- Telegram recipient edits preserve the stored bot token, chat ID and name when only Enabled/ID is submitted.
- When a VK account is declared exhausted, its persisted pool is invalidated so automatic recovery rebuilds fresh hashes instead of trusting stale dead hashes.
- The multi-account supervisor retries the other configured account if the current account cannot replenish its pool, rather than waiting indefinitely on one account.

### HydraRoute аварийное туннелирование

В режиме SOCKS5 qWDTT может автоматически перевести трафик на существующее нативное подключение HydraRoute, если qWDTT непрерывно не восстанавливается в течение 5 минут. CAPTCHA, rate-limit и кратковременные ошибки сами по себе не переключают маршрут. После активации HydraRoute failover является фиксированным (latched): даже после восстановления qWDTT трафик остаётся на HydraRoute до ручного выключения переключателя в веб-панели qWDTT.

Переключатель панели имеет три логических состояния: резерв выключен; резерв включён и ожидает; HydraRoute туннелирование активно. Ручное выключение вызывает восстановление исходного состояния Keenetic IP Policy и запрещает повторную автоматическую активацию до следующего ручного включения.


### DNS по умолчанию (1.0.32)

Клиент qWDTT по умолчанию использует локальный DNS-резолвер Keenetic (`192.168.1.1:53`). Это означает, что фактические DNS-серверы берутся из настроек роутера. Яндекс DNS не прописывается жёстко в qWDTT. При необходимости доступны режимы `yandex`, `cloudflare`, `google`, `custom:IP` и DoH.

- The five-minute HydraRoute failover clock is persisted on disk. An unexpected qWDTT process or web-panel restart cannot reset the downtime timer; an intentional manual tunnel stop is excluded from automatic failover.
