#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SRC=${1:-}
if [ -z "$SRC" ]; then
  echo "usage: $0 /path/to/wdtt-server-linux-amd64-or-arm64" >&2
  exit 2
fi
case "$SRC" in
  *wdtt-server-linux-amd64) ARCH=amd64 ;;
  *wdtt-server-linux-arm64) ARCH=arm64 ;;
  *) echo "ERROR: имя бинарника должно заканчиваться wdtt-server-linux-amd64 или wdtt-server-linux-arm64" >&2; exit 2 ;;
esac
mkdir -p "$ROOT/entware/deploy"
install -m 700 "$SRC" "$ROOT/entware/deploy/wdtt-server-$ARCH"
ln -sfn "wdtt-server-$ARCH" "$ROOT/entware/deploy/wdtt-server"
sha256sum "$ROOT/entware/deploy/wdtt-server-$ARCH"
echo "Staged $ARCH -> entware/deploy/wdtt-server"
