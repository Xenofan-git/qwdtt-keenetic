#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
GO_VERSION_REQUIRED=1.26
: "${GO_BIN:=go}"
if ! command -v "$GO_BIN" >/dev/null 2>&1; then echo "go not found" >&2; exit 1; fi
case "$("$GO_BIN" version)" in *"go1.26"*|*"go1.27"*|*"go1.28"*) ;; *) echo "This source requires Go ${GO_VERSION_REQUIRED}+; found: $("$GO_BIN" version)" >&2; exit 2;; esac
mkdir -p "$ROOT/build/arm64"
cd "$ROOT/go_client"
CGO_ENABLED=0 GOOS=linux GOARCH=arm64 "$GO_BIN" build -trimpath -ldflags='-s -w' -o "$ROOT/build/arm64/qwdtt" .
cd "$ROOT/entware/web"
CGO_ENABLED=0 GOOS=linux GOARCH=arm64 "$GO_BIN" build -trimpath -ldflags='-s -w' -o "$ROOT/build/arm64/qwdtt-web" .
echo "Built: $ROOT/build/arm64/qwdtt"
echo "Built: $ROOT/build/arm64/qwdtt-web"
