#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
PREFIX=${PREFIX:-/opt}
ETC="$PREFIX/etc/qwdtt"
BIN="$PREFIX/bin"
mkdir -p "$ETC" "$ETC/web/static" "$ETC/deploy" "$ETC/logs" "$PREFIX/etc/init.d"
[ -f "$ROOT/build/arm64/qwdtt" ] || { echo "Missing build/arm64/qwdtt. Run scripts/build-arm64.sh first." >&2; exit 2; }
[ -f "$ROOT/build/arm64/qwdtt-web" ] || { echo "Missing build/arm64/qwdtt-web. Run scripts/build-arm64.sh first." >&2; exit 2; }
install -m 0755 "$ROOT/build/arm64/qwdtt" "$BIN/qwdtt"
install -m 0755 "$ROOT/build/arm64/qwdtt-web" "$BIN/qwdtt-web"
cp -a "$ROOT/entware/config/." "$ETC/"
if [ ! -f "$ETC/web.auth" ]; then
  WEB_PASS=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 24)
  printf "admin:%s\n" "$WEB_PASS" > "$ETC/web.auth"
  chmod 600 "$ETC/web.auth"
  echo "qWDTT web login: admin / $WEB_PASS"
fi
[ -f "$ROOT/entware/config/vk.env.example" ] && install -m 0600 "$ROOT/entware/config/vk.env.example" "$ETC/vk.env.example"
cp -a "$ROOT/entware/deploy/." "$ETC/deploy/"
cp -a "$ROOT/entware/web/static/." "$ETC/web/static/"
install -m 0755 "$ROOT/entware/init.d/S97qwdtt-proxy" "$PREFIX/etc/init.d/S97qwdtt-proxy"
install -m 0755 "$ROOT/entware/init.d/S97qwdtt-failover" "$PREFIX/etc/init.d/S97qwdtt-failover"
install -m 0755 "$ROOT/entware/init.d/S98qwdtt-web" "$PREFIX/etc/init.d/S98qwdtt-web"
install -m 0755 "$ROOT/entware/init.d/S99qwdtt" "$PREFIX/etc/init.d/S99qwdtt"
# Create the native Keenetic SOCKS5 connection immediately when ndmc is available.
if [ -x "$PREFIX/etc/init.d/S97qwdtt-proxy" ]; then
  "$PREFIX/etc/init.d/S97qwdtt-proxy" start 192.168.1.1 1301 || echo "Warning: Keenetic SOCKS5 interface was not created automatically; run S97qwdtt-proxy start later."
fi
echo "Installed qWDTT Entware into $PREFIX"
