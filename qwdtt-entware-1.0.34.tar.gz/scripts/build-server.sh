#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT="$ROOT/build/server"
GO_BIN="${GO_BIN:-go}"
GO_VERSION="$($GO_BIN version | awk '{print $3}' || true)"
case "$GO_VERSION" in
  go1.2[5-9].*|go1.[3-9][0-9].*) ;;
  *) echo "ERROR: нужен Go 1.25+ (найден: ${GO_VERSION:-unknown})" >&2; exit 1;;
esac
mkdir -p "$OUT"
cd "$ROOT/server"
$GO_BIN mod download
for arch in amd64 arm64; do
  echo "==> wdtt-server linux/$arch"
  CGO_ENABLED=0 GOOS=linux GOARCH="$arch" \
    $GO_BIN build -trimpath -ldflags='-s -w' -o "$OUT/wdtt-server-linux-$arch" .
done
sha256sum "$OUT"/wdtt-server-linux-* > "$OUT/SHA256SUMS"
echo "Built: $OUT"
